import express from "express";
import path from "path";
import fs from "fs";
import AdmZip from "adm-zip";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route: Check overall service health
  app.get("/api/health", (req, res) => {
    res.json({ status: "healthy", timestamp: new Date().toISOString() });
  });

  // API Route: Get all list of project source files for our editor tree
  app.get("/api/project/files", (req, res) => {
    const parentDir = path.join(process.cwd(), "Personal_Finance_Management_System");
    if (!fs.existsSync(parentDir)) {
      return res.status(404).json({ error: "Python project directory does not exist." });
    }

    try {
      const files = fs.readdirSync(parentDir);
      const fileDataList: { fileName: string; content: string }[] = [];

      for (const file of files) {
        const filePath = path.join(parentDir, file);
        const stat = fs.statSync(filePath);

        // Serve only text/source files, skip DB or binary reports in the editor text view
        if (stat.isFile() && !file.endsWith(".db") && !file.endsWith(".xlsx") && !file.endsWith(".png")) {
          const content = fs.readFileSync(filePath, "utf-8");
          fileDataList.push({ fileName: file, content });
        }
      }

      res.json({ files: fileDataList });
    } catch (err: any) {
      res.status(500).json({ error: `Failed to compile files: ${err.message}` });
    }
  });

  // API Route: Save edited text content to the filesystem
  app.post("/api/project/files/save", (req, res) => {
    const { fileName, content } = req.body;
    if (!fileName || typeof content !== "string") {
      return res.status(400).json({ error: "Filename and content strings are required." });
    }

    const sanitizedFile = path.basename(fileName);
    const targetPath = path.join(process.cwd(), "Personal_Finance_Management_System", sanitizedFile);

    try {
      fs.writeFileSync(targetPath, content, "utf-8");
      res.json({ success: true, message: `Successfully updated ${sanitizedFile}` });
    } catch (err: any) {
      res.status(500).json({ error: `Save failed: ${err.message}` });
    }
  });

  // API Route: Zip the entire workspace for direct download
  app.get("/api/project/download", (req, res) => {
    const projectDir = path.join(process.cwd(), "Personal_Finance_Management_System");
    if (!fs.existsSync(projectDir)) {
      return res.status(404).json({ error: "Source folder not found." });
    }

    try {
      const zip = new AdmZip();
      
      // Read all contents and pack them
      const files = fs.readdirSync(projectDir);
      for (const file of files) {
        const filePath = path.join(projectDir, file);
        const stat = fs.statSync(filePath);

        if (stat.isFile()) {
          // Zip text files or binaries, just not the dynamic lock files
          const fileContent = fs.readFileSync(filePath);
          zip.addFile(`Personal_Finance_Management_System/${file}`, fileContent);
        }
      }

      const zipBuffer = zip.toBuffer();
      res.set({
        "Content-Type": "application/zip",
        "Content-Disposition": "attachment; filename=Personal_Finance_Management_System.zip",
        "Content-Length": zipBuffer.length,
      });

      res.send(zipBuffer);
    } catch (err: any) {
      res.status(500).json({ error: `ZIP failed: ${err.message}` });
    }
  });

  // Vite middleware integration based on standard React setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`🚀 Node.js Applet Server active at http://0.0.0.0:${PORT}`);
  });
}

startServer();
