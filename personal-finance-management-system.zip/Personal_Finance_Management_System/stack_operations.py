class StackNode:
    """Node for custom Stack implementation."""
    def __init__(self, data):
        self.data = data
        self.next = None

class ActionStack:
    """
    Core Stack implementation (LIFO) using a linked list structure internally.
    Used for the 'Undo Last Transaction' operation.
    """
    def __init__(self):
        self.top = None
        self.size = 0

    def push(self, action_type: str, table_name: str, record_id: int, prev_data: dict = None) -> None:
        """
        Pushes a new undoable action onto the stack.
        
        Args:
            action_type: "ADD", "DELETE", or "UPDATE"
            table_name: "Income" or "Expense"
            record_id: Database auto-generated primary key
            prev_data: Dictionary representing records before change (for UPDATE/DELETE)
        """
        payload = {
            "type": action_type,
            "table": table_name,
            "id": record_id,
            "data": prev_data or {}
        }
        new_node = StackNode(payload)
        new_node.next = self.top
        self.top = new_node
        self.size += 1

    def pop(self) -> dict:
        """Pops and returns the top action from the stack."""
        if self.is_empty():
            return None
        popped_node = self.top
        self.top = self.top.next
        self.size -= 1
        return popped_node.data

    def peek(self) -> dict:
        """Look at the top action without removing it."""
        if self.is_empty():
            return None
        return self.top.data

    def is_empty(self) -> bool:
        """Checks if the stack has no actions."""
        return self.top is None

    def get_size(self) -> int:
        """Returns the current size of the Stack."""
        return self.size

    def clear(self) -> None:
        """Clears the entire undo stack."""
        self.top = None
        self.size = 0


class UndoEngine:
    """
    Integrates ActionStack with the SQLite Database to perform physical database undos.
    """
    def __init__(self, db_manager, undo_stack: ActionStack):
        self.db = db_manager
        self.stack = undo_stack

    def perform_undo(self) -> bool:
        """
        Reverts the latest transaction stored in the undo stack.
        Returns True if successful, False otherwise.
        """
        action = self.stack.pop()
        if not action:
            print("📭 Nothing to undo: No recent transactions recorded in this session.")
            return False

        action_type = action["type"]
        table = action["table"]
        record_id = action["id"]
        data = action["data"]

        try:
            if action_type == "ADD":
                # To undo an addition, we delete the inserted record
                query = f"DELETE FROM {table} WHERE id = ?"
                self.db.execute_query(query, (record_id,))
                print(f"↩️ Undo Successful: Removed newly added {table} entry (ID: {record_id}).")
                return True

            elif action_type == "DELETE":
                # To undo a deletion, we insert the deleted record back with its original details
                if table == "Income":
                    query = "INSERT INTO Income (id, user_id, amount, source, date) VALUES (?, ?, ?, ?, ?)"
                    params = (record_id, data["user_id"], data["amount"], data["source"], data["date"])
                else:  # Expense
                    query = "INSERT INTO Expense (id, user_id, amount, category, date) VALUES (?, ?, ?, ?, ?)"
                    params = (record_id, data["user_id"], data["amount"], data["category"], data["date"])

                self.db.execute_query(query, params)
                print(f"↩️ Undo Successful: Restored deleted {table} entry (ID: {record_id}).")
                return True

            elif action_type == "UPDATE":
                # To undo an update, we write the pre-update data back
                if table == "Income":
                    query = "UPDATE Income SET amount = ?, source = ?, date = ? WHERE id = ?"
                    params = (data["amount"], data["source"], data["date"], record_id)
                else: # Expense
                    query = "UPDATE Expense SET amount = ?, category = ?, date = ? WHERE id = ?"
                    params = (data["amount"], data["category"], data["date"], record_id)

                self.db.execute_query(query, params)
                print(f"↩️ Undo Successful: Restored updated {table} entry to previous values (ID: {record_id}).")
                return True

        except Exception as e:
            print(f"❌ Undo Execution Error: {e}")
            return False

        return False
