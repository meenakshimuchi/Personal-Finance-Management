import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from database import DatabaseManager

class ExcelReporter:
    """
    Constructs high-fidelity stylized MS Excel sheets (.xlsx)
    combining tabular raw details and corporate financial summaries.
    """
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager

    def generate_report(self, user_id: int, file_path="finance_report.xlsx") -> bool:
        """
        Gathers income, expense, and summaries from SQLite and compiles them
        into multiple elegantly styled sheets inside one workbook file.
        """
        # Fetch Data
        incomes = self.db.fetch_all(
            "SELECT id, amount, source, date FROM Income WHERE user_id = ? ORDER BY date DESC",
            (user_id,)
        )
        expenses = self.db.fetch_all(
            "SELECT id, amount, category, date FROM Expense WHERE user_id = ? ORDER BY date DESC",
            (user_id,)
        )

        # Totals
        total_income = sum(row[1] for row in incomes)
        total_expense = sum(row[1] for row in expenses)
        balance = total_income - total_expense

        # Initialize OpenPyXL Workbook
        wb = openpyxl.Workbook()
        
        # Styles
        font_family = "Segoe UI"
        header_font = Font(name=font_family, size=11, bold=True, color="FFFFFF")
        title_font = Font(name=font_family, size=14, bold=True, color="1B365D")
        label_font = Font(name=font_family, size=10, bold=True, color="000000")
        regular_font = Font(name=font_family, size=10)
        italic_font = Font(name=font_family, size=9, italic=True, color="555555")

        navy_fill = PatternFill(start_color="1B365D", end_color="1B365D", fill_type="solid")
        amber_fill = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")
        cyan_fill = PatternFill(start_color="E6EEF8", end_color="E6EEF8", fill_type="solid")
        
        center_align = Alignment(horizontal="center", vertical="center")
        left_align = Alignment(horizontal="left", vertical="center")
        right_align = Alignment(horizontal="right", vertical="center")

        thin_side = Side(style='thin', color='DDDDDD')
        thin_border = Border(left=thin_side, right=thin_side, top=thin_side, bottom=thin_side)
        double_bottom = Border(bottom=Side(style='double', color='1B365D'), top=Side(style='thin', color='DDDDDD'))

        # ==========================================
        # SHEET 1: OVERVIEW & MONTHLY SUMMARY
        # ==========================================
        ws_summary = wb.active
        ws_summary.title = "Executive Summary"
        ws_summary.views.sheetView[0].showGridLines = True

        ws_summary.cell(row=2, column=2, value="Personal Finance Executive Summary").font = title_font
        ws_summary.row_dimensions[2].height = 25

        headers_summary = ["Financial Indicator", "Cumulative Balance ($)"]
        for idx, h in enumerate(headers_summary, start=2):
            cell = ws_summary.cell(row=4, column=idx, value=h)
            cell.font = header_font
            cell.fill = navy_fill
            cell.alignment = center_align
            cell.border = thin_border
        ws_summary.row_dimensions[4].height = 20

        indicators = [
            ("Total Registered Income", total_income, "000000"),
            ("Total Logged Expenses", total_expense, "000000"),
            ("Remaining Wallet Balance", balance, "1B365D" if balance >= 0 else "9C0006")
        ]

        for i, (indicator, value, hex_color) in enumerate(indicators):
            row_idx = 5 + i
            # Indicator Label
            cell_lbl = ws_summary.cell(row=row_idx, column=2, value=indicator)
            cell_lbl.font = label_font
            cell_lbl.alignment = left_align
            cell_lbl.border = thin_border
            if i == 2:
                cell_lbl.fill = amber_fill

            # Indicator Value
            cell_val = ws_summary.cell(row=row_idx, column=3, value=value)
            cell_val.font = Font(name=font_family, size=10, bold=True, color=hex_color)
            cell_val.alignment = right_align
            cell_val.number_format = "$#,##0.00"
            cell_val.border = thin_border
            if i == 2:
                cell_val.fill = amber_fill
            ws_summary.row_dimensions[row_idx].height = 18

        # Style columns block
        ws_summary.column_dimensions['B'].width = 30
        ws_summary.column_dimensions['C'].width = 25

        # ==========================================
        # SHEET 2: INCOME ENTRIES
        # ==========================================
        ws_income = wb.create_sheet(title="Income Detailed Ledger")
        ws_income.views.sheetView[0].showGridLines = True
        
        ws_income.cell(row=2, column=2, value="Detailed Income Log").font = title_font
        ws_income.row_dimensions[2].height = 25

        inc_headers = ["Transaction ID", "Amount Received", "Source Descriptor", "Credit Date"]
        for idx, h in enumerate(inc_headers, start=2):
            cell = ws_income.cell(row=4, column=idx, value=h)
            cell.font = header_font
            cell.fill = navy_fill
            cell.alignment = center_align
            cell.border = thin_border
        ws_income.row_dimensions[4].height = 20

        for idx, item in enumerate(incomes):
            r_idx = 5 + idx
            ws_income.row_dimensions[r_idx].height = 18
            
            # ID
            c = ws_income.cell(row=r_idx, column=2, value=item[0])
            c.font = regular_font; c.alignment = center_align; c.border = thin_border
            # Amount
            c = ws_income.cell(row=r_idx, column=3, value=item[1])
            c.font = regular_font; c.alignment = right_align; c.border = thin_border; c.number_format = "$#,##0.00"
            # Source
            c = ws_income.cell(row=r_idx, column=4, value=item[2])
            c.font = regular_font; c.alignment = left_align; c.border = thin_border
            # Date
            c = ws_income.cell(row=r_idx, column=5, value=item[3])
            c.font = regular_font; c.alignment = center_align; c.border = thin_border

        # Total Line
        tot_row = 5 + len(incomes)
        ws_income.cell(row=tot_row, column=3, value=f"=SUM(C5:C{tot_row-1})").number_format = "$#,##0.00"
        ws_income.cell(row=tot_row, column=3).font = label_font
        ws_income.cell(row=tot_row, column=3).border = double_bottom
        ws_income.cell(row=tot_row, column=2, value="Sum Total").font = label_font
        ws_income.cell(row=tot_row, column=2).alignment = center_align
        ws_income.cell(row=tot_row, column=2).border = double_bottom

        # Auto width
        ws_income.column_dimensions['B'].width = 15
        ws_income.column_dimensions['C'].width = 20
        ws_income.column_dimensions['D'].width = 25
        ws_income.column_dimensions['E'].width = 18

        # ==========================================
        # SHEET 3: EXPENSE ENTRIES
        # ==========================================
        ws_expense = wb.create_sheet(title="Expense Detailed Ledger")
        ws_expense.views.sheetView[0].showGridLines = True

        ws_expense.cell(row=2, column=2, value="Detailed Expense Log").font = title_font
        ws_expense.row_dimensions[2].height = 25

        exp_headers = ["Transaction ID", "Amount Charged", "Expense Category", "Debit Date"]
        for idx, h in enumerate(exp_headers, start=2):
            cell = ws_expense.cell(row=4, column=idx, value=h)
            cell.font = header_font
            cell.fill = navy_fill
            cell.alignment = center_align
            cell.border = thin_border
        ws_expense.row_dimensions[4].height = 20

        for idx, item in enumerate(expenses):
            r_idx = 5 + idx
            ws_expense.row_dimensions[r_idx].height = 18
            
            # ID
            c = ws_expense.cell(row=r_idx, column=2, value=item[0])
            c.font = regular_font; c.alignment = center_align; c.border = thin_border
            # Amount
            c = ws_expense.cell(row=r_idx, column=3, value=item[1])
            c.font = regular_font; c.alignment = right_align; c.border = thin_border; c.number_format = "$#,##0.00"
            # Category
            c = ws_expense.cell(row=r_idx, column=4, value=item[2])
            c.font = regular_font; c.alignment = center_align; c.border = thin_border
            # Date
            c = ws_expense.cell(row=r_idx, column=5, value=item[3])
            c.font = regular_font; c.alignment = center_align; c.border = thin_border

        # Total Line
        tot_row = 5 + len(expenses)
        ws_expense.cell(row=tot_row, column=3, value=f"=SUM(C5:C{tot_row-1})").number_format = "$#,##0.00"
        ws_expense.cell(row=tot_row, column=3).font = label_font
        ws_expense.cell(row=tot_row, column=3).border = double_bottom
        ws_expense.cell(row=tot_row, column=2, value="Sum Total").font = label_font
        ws_expense.cell(row=tot_row, column=2).alignment = center_align
        ws_expense.cell(row=tot_row, column=2).border = double_bottom

        # Auto width
        ws_expense.column_dimensions['B'].width = 15
        ws_expense.column_dimensions['C'].width = 20
        ws_expense.column_dimensions['D'].width = 25
        ws_expense.column_dimensions['E'].width = 18

        # Save workbook
        wb.save(file_path)
        print(f"📊 Spreadsheet Compiled Successfully: Saved to '{file_path}'.")
        return True
