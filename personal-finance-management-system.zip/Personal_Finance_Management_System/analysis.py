import pandas as pd
from database import DatabaseManager

class FinanceAnalyzer:
    """
    Performs data science transformations and calculations using Pandas
    to produce deep financial metrics for the system.
    """
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager

    def _get_income_dataframe(self, user_id: int) -> pd.DataFrame:
        """Retrieves and packages income statistics in a Pandas DataFrame."""
        records = self.db.fetch_all(
            "SELECT amount, source, date FROM Income WHERE user_id = ?",
            (user_id,)
        )
        return pd.DataFrame(records, columns=["Amount", "Source", "Date"])

    def _get_expense_dataframe(self, user_id: int) -> pd.DataFrame:
        """Retrieves and packages expense statistics in a Pandas DataFrame."""
        records = self.db.fetch_all(
            "SELECT amount, category, date FROM Expense WHERE user_id = ?",
            (user_id,)
        )
        return pd.DataFrame(records, columns=["Amount", "Category", "Date"])

    def get_highest_expense_category(self, user_id: int) -> dict:
        """Returns the category that contains the maximum cumulative spending."""
        df_exp = self._get_expense_dataframe(user_id)
        if df_exp.empty:
            return {"category": "N/A", "amount": 0.0}
        
        # Group by category and sum expenditure
        category_sums = df_exp.groupby("Category")["Amount"].sum()
        highest_cat = category_sums.idxmax()
        highest_val = category_sums.max()
        return {"category": highest_cat, "amount": float(highest_val)}

    def get_monthly_spending_trend(self, user_id: int) -> dict:
        """Computes Total Expenses grouped by Month (YYYY-MM)."""
        df_exp = self._get_expense_dataframe(user_id)
        if df_exp.empty:
            return {}
        
        # Convert Date to datetime and extract Year-Month
        df_exp["Date"] = pd.to_datetime(df_exp["Date"])
        df_exp["Month"] = df_exp["Date"].dt.to_period("M").astype(str)
        
        trend = df_exp.groupby("Month")["Amount"].sum()
        return trend.to_dict()

    def get_average_monthly_expenditure(self, user_id: int) -> float:
        """Calculates historical mean spendings across all recorded active months."""
        df_exp = self._get_expense_dataframe(user_id)
        if df_exp.empty:
            return 0.0

        df_exp["Date"] = pd.to_datetime(df_exp["Date"])
        df_exp["Month"] = df_exp["Date"].dt.to_period("M")
        
        # Total per month, then average of month totals
        monthly_totals = df_exp.groupby("Month")["Amount"].sum()
        return float(monthly_totals.mean())

    def get_savings_percentage(self, user_id: int) -> float:
        """
        Calculates savings percentage over entire lifetime records.
        Savings% = [(Total Income - Total Expenses) / Total Income] * 100
        """
        df_inc = self._get_income_dataframe(user_id)
        df_exp = self._get_expense_dataframe(user_id)

        total_income = df_inc["Amount"].sum() if not df_inc.empty else 0.0
        total_expense = df_exp["Amount"].sum() if not df_exp.empty else 0.0

        if total_income == 0:
            return 0.0

        savings = total_income - total_expense
        savings_pct = (savings / total_income) * 100
        return float(max(0, savings_pct)) # Cap at 0 if net deficit

    def get_finance_summary(self, user_id: int) -> dict:
        """Fetches standard monetary balances."""
        df_inc = self._get_income_dataframe(user_id)
        df_exp = self._get_expense_dataframe(user_id)

        total_income = float(df_inc["Amount"].sum()) if not df_inc.empty else 0.0
        total_expense = float(df_exp["Amount"].sum()) if not df_exp.empty else 0.0
        balance = total_income - total_expense

        return {
            "total_income": total_income,
            "total_expense": total_expense,
            "balance": balance,
            "savings_percentage": self.get_savings_percentage(user_id),
            "highest_category": self.get_highest_expense_category(user_id),
            "monthly_average": self.get_average_monthly_expenditure(user_id)
        }
