import sys
from datetime import datetime

# Import sub-modules
from database import DatabaseManager
from login import AuthManager
from income import IncomeManager
from expense import ExpenseManager
from stack_operations import ActionStack, UndoEngine
from queue_operations import RecentTransactionQueue
from linkedlist import TransactionHistoryList
from analysis import FinanceAnalyzer
from excel_export import ExcelReporter
from tableau_data import TableauExporter


class PersonalFinanceSystem:
    """
    Main controller class that orchestrates execution, views, database syncs,
    and state transitions in the console.
    """
    def __init__(self):
        self.db = DatabaseManager()
        self.auth = AuthManager(self.db)
        self.income_mgr = IncomeManager(self.db)
        self.expense_mgr = ExpenseManager(self.db)
        
        # DSA Structures
        self.undo_stack = ActionStack()
        self.undo_engine = UndoEngine(self.db, self.undo_stack)
        self.recent_queue = RecentTransactionQueue(capacity=5)
        self.history_list = TransactionHistoryList()
        
        # Services
        self.analyzer = FinanceAnalyzer(self.db)
        self.excel_service = ExcelReporter(self.db)
        self.tableau_service = TableauExporter(self.db)

        # Active Session state
        self.active_user_id = None
        self.active_username = None

    def load_transaction_history_linked_list(self):
        """Loads and sorts database records into the dynamic Linked List."""
        if not self.active_user_id:
            return
        
        self.history_list.clear()
        
        # Load Incomes
        incomes = self.income_mgr.get_by_user(self.active_user_id)
        for inc in incomes:
            self.history_list.append(inc.id, "Income", inc.amount, inc.source, inc.date)

        # Load Expenses
        expenses = self.expense_mgr.get_by_user(self.active_user_id)
        for exp in expenses:
            self.history_list.append(exp.id, "Expense", exp.amount, exp.category, exp.date)

        # Perform custom sorting algorithm
        self.history_list.sort_by_date_descending()

    def run(self):
        """Infinite loop driving CLI console options."""
        while True:
            print("\n" + "="*50)
            print("💰 PERSONAL FINANCE MANAGEMENT SYSTEM (PFMS) 💰")
            print("="*50)
            
            if not self.active_user_id:
                print("1. Register User Profile")
                print("2. Login to Active Session")
                print("3. Reset Forgotten Password")
                print("0. Shut Down Application")
                print("-" * 50)
                choice = input("Enter option index: ").strip()

                if choice == "1":
                    self.ui_register()
                elif choice == "2":
                    self.ui_login()
                elif choice == "3":
                    self.ui_reset_password()
                elif choice == "0":
                    print("\nThank you for using PFMS. Safe savings! Goodbye.")
                    self.db.close()
                    sys.exit(0)
                else:
                    print("❌ Warning: Selection not recognized. Retry.")
            else:
                print(f"🔒 Session Active: {self.active_username} (User ID: {self.active_user_id})")
                print("-" * 50)
                print("1. Add Income Source")
                print("2. Add Expense Ledger")
                print("3. View Sorted Transactions History (Linked List)")
                print("4. Update Existing Record")
                print("5. Delete Existing Record")
                print("6. Undo Last Database Action (Stack)")
                print("7. Financial Indicators Summary (Pandas)")
                print("8. Export stylized Report to MS Excel (OpenPyXL)")
                print("9. Compile Tableau Data Layer (CSV)")
                print("10. View Recent Session Notifications (Queue)")
                print("0. Terminate User Session / Logout")
                print("-" * 50)
                choice = input("Enter option index: ").strip()

                if choice == "1":
                    self.ui_add_income()
                elif choice == "2":
                    self.ui_add_expense()
                elif choice == "3":
                    self.ui_view_history()
                elif choice == "4":
                    self.ui_update_record()
                elif choice == "5":
                    self.ui_delete_record()
                elif choice == "6":
                    self.ui_undo_transaction()
                elif choice == "7":
                    self.ui_financial_indicators()
                elif choice == "8":
                    self.ui_export_excel()
                elif choice == "9":
                    self.ui_compile_tableau()
                elif choice == "10":
                    self.ui_view_queue()
                elif choice == "0":
                    print(f"\n🔐 Terminating Session. {self.active_username} logged out.")
                    self.active_user_id = None
                    self.active_username = None
                    self.undo_stack.clear()
                else:
                    print("❌ Warning: Selection not recognized. Retry.")

    # UI Helpers & Action Pipelines
    def ui_register(self):
        print("\n📝 USER PROFILE REGISTRATION")
        username = input("Choose Username: ").strip()
        if not username:
            print("❌ Username cannot be blank.")
            return
        password = input("Choose Password: ")
        if len(password) < 4:
            print("❌ Security warning: Password must exceed 3 letters.")
            return
        
        print("\nTo enable secure password recovery, enter a security question.")
        question = input("Security Question (e.g., 'What is your favorite book?'): ").strip()
        answer = input("Your Private Answer: ").strip()

        if not question or not answer:
            print("❌ Question or security answer cannot be blanks.")
            return

        self.auth.register(username, password, question, answer)

    def ui_login(self):
        print("\n🔐 USER AUTHENTICATION")
        username = input("Username: ").strip()
        password = input("Password: ")
        
        uid = self.auth.login(username, password)
        if uid:
            self.active_user_id = uid
            self.active_username = username
            self.load_transaction_history_linked_list()
            self.recent_queue.enqueue(f"🔓 User '{username}' logged in successfully.")

    def ui_reset_password(self):
        print("\n🌀 PASSWORD RESET RECOVERY")
        username = input("Username: ").strip()
        
        # Fetch question
        rec = self.db.fetch_one("SELECT security_question FROM Users WHERE username = ?", (username,))
        if not rec:
            print("❌ Username record unrecognized.")
            return

        print(f"Question: {rec[0]}")
        answer = input("Answer: ").strip()
        new_pwd = input("New Password: ")
        if len(new_pwd) < 4:
            print("❌ Password must exceed 3 letters.")
            return
        
        self.auth.reset_password(username, answer, new_pwd)

    def ui_add_income(self):
        print("\n📈 ADD INCOME TRANSACTION")
        try:
            amount = float(input("Amount ($): "))
            source = input("Source of Credit (e.g., Salary, Cashback): ").strip()
            date_str = input("Date (YYYY-MM-DD or leave empty for Today): ").strip()
            
            if not date_str:
                date_str = datetime.today().strftime('%Y-%m-%d')
            else:
                datetime.strptime(date_str, '%Y-%m-%d') # validate format
            
            inserted_id = self.income_mgr.add(self.active_user_id, amount, source, date_str)
            if inserted_id:
                # Add command payload to undo stack
                self.undo_stack.push("ADD", "Income", inserted_id, None)
                # Queue reporting
                self.recent_queue.enqueue(f"📈 Added: ${amount:.2f} income from '{source}' on {date_str}.")
                # Reload LL state
                self.load_transaction_history_linked_list()
        except ValueError as e:
            print(f"❌ Invalid Entry Format: {e}")

    def ui_add_expense(self):
        print("\n📉 ADD EXPENSE TRANSACTION")
        print(f"Categories supported: {', '.join(self.expense_mgr.VALID_CATEGORIES)}")
        try:
            amount = float(input("Amount ($): "))
            category = input("Select Category: ").strip()
            date_str = input("Date (YYYY-MM-DD or leave empty for Today): ").strip()

            if not date_str:
                date_str = datetime.today().strftime('%Y-%m-%d')
            else:
                datetime.strptime(date_str, '%Y-%m-%d') # validate format

            inserted_id = self.expense_mgr.add(self.active_user_id, amount, category, date_str)
            if inserted_id:
                # Add to undo stack
                self.undo_stack.push("ADD", "Expense", inserted_id, None)
                # Queue reporting
                self.recent_queue.enqueue(f"📉 Added: ${amount:.2f} expense for '{category}' on {date_str}.")
                # Reload LL state
                self.load_transaction_history_linked_list()
        except ValueError as e:
            print(f"❌ Invalid Entry Format: {e}")

    def ui_view_history(self):
        print("\n📜 TRANSACTION HISTORY (Sorted Linked List traversal)")
        self.load_transaction_history_linked_list()
        
        txs = self.history_list.to_python_list()
        if not txs:
            print("📭 Empty Ledger: No financial items entered.")
            return

        print(f"{'TX ID':<8} | {'Type':<8} | {'Amount ($)':<12} | {'Category/Source':<20} | {'Date':<12}")
        print("-" * 65)
        for tx in txs:
            amt_fmt = f"${tx['amount']:.2f}"
            print(f"{tx['id']:<8} | {tx['type']:<8} | {amt_fmt:<12} | {tx['category_or_source']:<20} | {tx['date']:<12}")
        print("-" * 65)
        print(f"Total Traversed Records: {self.history_list.count()}")

    def ui_update_record(self):
        print("\n✏️ UPDATE EXISTING TRANSACTION")
        tx_type = input("Transaction Type to Update (Income / Expense): ").strip().capitalize()
        if tx_type not in ["Income", "Expense"]:
            print("❌ Invalid Type Selection.")
            return

        try:
            tx_id = int(input("Enter Transaction ID to update: "))
            
            # Fetch previous state first to push to Undo Stack
            prev_row = None
            if tx_type == "Income":
                row = self.db.fetch_one("SELECT amount, source, date FROM Income WHERE id = ? AND user_id = ?", (tx_id, self.active_user_id))
                if row:
                    prev_row = {"amount": row[0], "source": row[1], "date": row[2], "user_id": self.active_user_id}
            else: # Expense
                row = self.db.fetch_one("SELECT amount, category, date FROM Expense WHERE id = ? AND user_id = ?", (tx_id, self.active_user_id))
                if row:
                    prev_row = {"amount": row[0], "category": row[1], "date": row[2], "user_id": self.active_user_id}

            if not prev_row:
                print("❌ Record not found or access restricted.")
                return

            print(f"Active Record details: {prev_row}")
            new_amount = float(input("Enter new Amount ($): "))
            
            if tx_type == "Income":
                new_source = input("Enter new Source: ").strip()
                new_date = input("Enter new Date (YYYY-MM-DD): ").strip()
                
                success = self.income_mgr.update(tx_id, self.active_user_id, new_amount, new_source, new_date)
                if success:
                    self.undo_stack.push("UPDATE", "Income", tx_id, prev_row)
                    self.recent_queue.enqueue(f"✏️ Updated Income ID {tx_id}: New balance ${new_amount:.2f}")
                    self.load_transaction_history_linked_list()
            else:
                new_category = input("Enter new Category: ").strip()
                new_date = input("Enter new Date (YYYY-MM-DD): ").strip()
                
                success = self.expense_mgr.update(tx_id, self.active_user_id, new_amount, new_category, new_date)
                if success:
                    self.undo_stack.push("UPDATE", "Expense", tx_id, prev_row)
                    self.recent_queue.enqueue(f"✏️ Updated Expense ID {tx_id}: New balance ${new_amount:.2f}")
                    self.load_transaction_history_linked_list()

        except ValueError as e:
            print(f"❌ Invalid Input: {e}")

    def ui_delete_record(self):
        print("\n🗑️ DELETE EXISTING TRANSACTION")
        tx_type = input("Transaction Type to Delete (Income / Expense): ").strip().capitalize()
        if tx_type not in ["Income", "Expense"]:
            print("❌ Invalid Selection.")
            return

        try:
            tx_id = int(input("Enter Transaction ID to delete: "))
            
            # Fetch state to push to Undo Stack
            prev_row = None
            if tx_type == "Income":
                row = self.db.fetch_one("SELECT amount, source, date FROM Income WHERE id = ? AND user_id = ?", (tx_id, self.active_user_id))
                if row:
                    prev_row = {"amount": row[0], "source": row[1], "date": row[2], "user_id": self.active_user_id}
            else: # Expense
                row = self.db.fetch_one("SELECT amount, category, date FROM Expense WHERE id = ? AND user_id = ?", (tx_id, self.active_user_id))
                if row:
                    prev_row = {"amount": row[0], "category": row[1], "date": row[2], "user_id": self.active_user_id}

            if not prev_row:
                print("❌ Record not found or access restricted.")
                return

            if tx_type == "Income":
                success = self.income_mgr.delete(tx_id, self.active_user_id)
                if success:
                    self.undo_stack.push("DELETE", "Income", tx_id, prev_row)
                    self.recent_queue.enqueue(f"🗑️ Deleted Income ID {tx_id}")
                    self.load_transaction_history_linked_list()
            else:
                success = self.expense_mgr.delete(tx_id, self.active_user_id)
                if success:
                    self.undo_stack.push("DELETE", "Expense", tx_id, prev_row)
                    self.recent_queue.enqueue(f"🗑️ Deleted Expense ID {tx_id}")
                    self.load_transaction_history_linked_list()

        except ValueError as e:
            print(f"❌ Selection error: {e}")

    def ui_undo_transaction(self):
        print("\n↩️ UNDO LAST SESSION TRANSACTION (Action Stack Pop)")
        self.undo_engine.perform_undo()
        self.load_transaction_history_linked_list()

    def ui_financial_indicators(self):
        print("\n📊 DATA ANALYSIS & KEY PERFORMANCE INDICATORS (Pandas calculations)")
        summary = self.analyzer.get_finance_summary(self.active_user_id)
        trend = self.analyzer.get_monthly_spending_trend(self.active_user_id)

        print("-" * 50)
        print(f"💸 Cumulative Registered Income: ${summary['total_income']:.2f}")
        print(f"🛒 Cumulative Logged Expenses:   ${summary['total_expense']:.2f}")
        print(f"💼 Current Ledger Balance:       ${summary['balance']:.2f}")
        print(f"☘️ Cumulative Savings Margin:    {summary['savings_percentage']:.1f}%")
        print(f"📉 Average Expenditure/Month:    ${summary['monthly_average']:.2f}")
        print(f"🔥 Categories with Most Costs:   {summary['highest_category']['category']} (${summary['highest_category']['amount']:.2f})")
        print("-" * 50)
        
        if trend:
            print("\n📈 Monthly Cost Outflow Distribution:")
            for m, total in trend.items():
                print(f"  📅 {m}: ${total:.2f}")
        else:
            print("📊 Insert historical transactions to populate monthly distributions.")

    def ui_export_excel(self):
        print("\n📊 WRITING DESIGNED EXCEL SHEETS (OpenPyXL Pipeline)")
        path = input("Enter output file name (default 'finance_report.xlsx'): ").strip()
        if not path:
            path = "finance_report.xlsx"
        
        success = self.excel_service.generate_report(self.active_user_id, path)
        if success:
            self.recent_queue.enqueue(f"📊 Exported designed excel report to '{path}'.")

    def ui_compile_tableau(self):
        print("\n📊 WRITING TABLEAU INGESTION DATASET (CSV Pipeline)")
        path = input("Enter output CSV file name (default 'transactions.csv'): ").strip()
        if not path:
            path = "transactions.csv"

        success = self.tableau_service.generate_csv(self.active_user_id, path)
        if success:
            self.recent_queue.enqueue(f"📊 CSV dataset compilation finished at '{path}'.")

    def ui_view_queue(self):
        print("\n🔔 RECENT ACTIVITIES WORKSPACE QUEUE (FIFO)")
        msgs = self.recent_queue.display_recent_notifications()
        if not msgs:
            print("📭 Empty alerts feed. Build active session transactions first!")
            return
        
        for idx, alert in enumerate(msgs, start=1):
            print(f"  [{idx}] {alert}")


if __name__ == "__main__":
    system = PersonalFinanceSystem()
    system.run()
