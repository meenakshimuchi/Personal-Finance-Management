# Personal Finance Management System (PFMS)

An elegant, object-oriented, and beginner-friendly console-based desktop application written in **Python**, integrated with a local relational **SQLite3** database, and powered by standard **Data Structures & Algorithms (DSA)** alongside **Pandas** and **OpenPyXL** for automated data analytics pipelines.

Designed specifically for academic evaluation and professional portfolio standards (e.g., first-year computer science B.Tech profiles), this system manages user registration/login and CRUD operations over income and expense records while demonstrating optimal core computer science principles.

---

## 🎯 Project Highlight & Resume Bullet Points

If you are putting this on your Resume, use these highly professional and tech-dense descriptions:

*   **Project Title**: Personal Finance Management System with Embedded Linear Data Structures
*   **Core Tech Stack**: Python 3, SQLite, Pandas, OpenPyXL, CSV Data Serialization
*   **Core Algorithms / CS Concepts**: Data Structures (Singly Linked List, LIFO Stack, rolling FIFO Queue), CRUD Operations, Password Securing/Hashing (SHA-256), Normalized DB Schema.

### 📝 Professional Resume Descriptors
*   Designed and engineered an OOP-based **Personal Finance Management System** utilizing **Python** and **SQLite3**, creating a securely hashed login framework (SHA-256) handling multi-user credentials.
*   Implemented core linear data structures from scratch, incorporating a **custom Stack (LIFO)** to power an instant transactional **Undo Engine** and a **custom Queue (FIFO)** to maintain a sliding session notification tracker.
*   Constructed a **custom Singly Linked List** with an embedded **Bubble Sort sorting algorithm** to aggregate, index, and traverse unified financial entries chronologically by date.
*   Integrated **Pandas DataFrames** to automate user metrics processing, calculating monthly consumption trends, average outflows, and multi-category expense aggregates.
*   Programmed a beautiful dynamic report exporter using **OpenPyXL** to format multi-sheet MS Excel workbooks with custom styles, borders, formulas, and visual highlights.
*   Serialized relational database records into structured, sorted CSV datasets tailored for seamless **Tableau/PowerBI dashboard ingestion** and line/area balance visualization.

---

## 📂 System File Architecture Explained

The project follows a clean, modular structure where separate layers handle storage, algorithms, analysis, and views:

```
Personal_Finance_Management_System/
│
├── main.py              # Main terminal loop, coordinator/coordinator of menus & actions
├── database.py          # SQLite database connection manager & Table migrations
├── login.py             # User registration, password resets, and SHA-256 secure hashing
├── income.py            # CRUD operations and validation rules for Incomes
├── expense.py           # CRUD operations and category validation for Expenses
├── stack_operations.py  # Custom Stack class (LIFO) powering the Undo pipeline
├── queue_operations.py  # Custom Queue class (FIFO) tracking a sliding session activity feed
├── linkedlist.py        # Custom Singly Linked List and sorting algorithm for chronologic logs
├── analysis.py          # Pandas aggregations, KPI evaluations, and spending categorizations
├── excel_export.py      # MS Excel document styling and multi-sheet formula building
├── tableau_data.py      # Chronological CSV serializer with dynamic running balances
├── finance.db           # Formed local SQLite3 database file *(automatically created)*
├── transactions.csv     # Tableau CSV output dataset file *(generated on-demand)*
├── finance_report.xlsx  # Styled MS Excel report file *(generated on-demand)*
└── README.md            # System handbook and educational project review
```

---

## 🧠 Data Structures & Algorithms (DSA) Implementation

To demonstrate standard Computer Science proficiency, PFMS replaces default Python data structures with custom implementations:

1.  **LIFO Stack (for Undo Last Action)**:
    *   **Structure**: Singly Linked nodes keeping action metadata (`ADD`, `UPDATE`, `DELETE`), target tables (`Income` / `Expense`), record ID pointers, and state-restoration payloads (previous values).
    *   **Use Cases**: Instant cancellation of the last transactional entry or field correction. When calling 'Undo', the top payload is popped off the stack, and SQL directives are dynamically constructed to reverse the operation (e.g. deleting an added item, re-inserting a deleted row, or restoring previous numbers of an update).
2.  **FIFO Queue (Session rolling Notifications)**:
    *   **Structure**: Singly Linked Queue keeping a strict FIFO sliding window of 5 elements maximum.
    *   **Use Cases**: Feeds in-session text notifications (e.g. `[1] User logged in`, `[2] Added Income $500`, etc.). If a sixth event takes place, the first-entered message is dequeued and discarded, preserving memory limits.
3.  **Singly Linked List & Bubble Sort (Chronological Log Aggregate)**:
    *   **Structure**: Unique nodes storing unified entries (Incomes and Expenses combined) for list-traversal pipelines.
    *   **Use Cases**: Allows clean traversals of ledger outputs. It utilizes a custom pointer-based **Bubble Sort** routine to order financial records chronologically by date (`YYYY-MM-DD`) dynamically, showing optimal CSBS concepts.

---

## 🛢️ SQLite Relational Schema & Table Creation Queries

PFMS runs on a local SQLite file database named `finance.db` containing three relational tables:

```sql
-- 1. Users Table (Multi-user security)
CREATE TABLE IF NOT EXISTS Users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    security_question TEXT NOT NULL,
    security_answer TEXT NOT NULL
);

-- 2. Income Table
CREATE TABLE IF NOT EXISTS Income (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    amount REAL NOT NULL CHECK(amount > 0),
    source TEXT NOT NULL,
    date TEXT NOT NULL, -- Format: YYYY-MM-DD
    FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
);

-- 3. Expense Table (Validated Category domain details)
CREATE TABLE IF NOT EXISTS Expense (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    amount REAL NOT NULL CHECK(amount > 0),
    category TEXT NOT NULL CHECK(category IN ('Food', 'Shopping', 'Travel', 'Education', 'Entertainment', 'Others')),
    date TEXT NOT NULL, -- Format: YYYY-MM-DD
    FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
);
```

---

## 🚀 Installation & Running Guide

### 1. Prerequisites
Ensure you have **Python 3.8+** installed. Install required packages using `npm` or pip:

```bash
pip install pandas openpyxl
```

### 2. Launching the System
From the root project folder, run the following command to start:

```bash
python main.py
```

---

## 💻 Sample Terminal Session Output

### A. Main Dashboard Authentication
```
==================================================
💰 PERSONAL FINANCE MANAGEMENT SYSTEM (PFMS) 💰
==================================================
1. Register User Profile
2. Login to Active Session
3. Reset Forgotten Password
0. Shut Down Application
--------------------------------------------------
Enter option index: 2

🔐 USER AUTHENTICATION
Username: admin
Password: ****
✅ Login Successful! Welcome, admin.
```

### B. Dynamic Active Session Menu
```
==================================================
💰 PERSONAL FINANCE MANAGEMENT SYSTEM (PFMS) 💰
==================================================
🔒 Session Active: admin (User ID: 1)
--------------------------------------------------
1. Add Income Source
2. Add Expense Ledger
3. View Sorted Transactions History (Linked List)
4. Update Existing Record
5. Delete Existing Record
6. Undo Last Database Action (Stack)
7. Financial Indicators Summary (Pandas)
8. Export stylized Report to MS Excel (OpenPyXL)
9. Compile Tableau Data Layer (CSV)
10. View Recent Session Notifications (Queue)
0. Terminate User Session / Logout
--------------------------------------------------
Enter option index: 7

📊 DATA ANALYSIS & KEY PERFORMANCE INDICATORS (Pandas calculations)
--------------------------------------------------
💸 Cumulative Registered Income: $4500.00
🛒 Cumulative Logged Expenses:   $1250.00
💼 Current Ledger Balance:       $3250.00
☘️ Cumulative Savings Margin:    72.2%
📉 Average Expenditure/Month:    $625.00
🔥 Categories with Most Costs:   Shopping ($800.00)
--------------------------------------------------

📈 Monthly Cost Outflow Distribution:
  📅 2026-05: $450.00
  📅 2026-06: $800.00
```

---

## 🔮 Future Enhancements (Academic Viva Prompts)
If asked about future developments by examiners, you can suggest:
1.  **Machine Learning Ingestion**: Hooking a regression model (like scikit-learn) with current Pandas histories to predict next month's category-wise overhead boundaries.
2.  **API Bank feeds**: Replacing local database logging with automated REST-API syncs to fetch real bank statement ledgers automatically.
3.  **Advanced Cryptography**: Migrating plain SHA-256 hashes to Salted Argon2id algorithms to prevent modern GPU-based dictionary database cracks.
