from database import DatabaseManager

class IncomeRecord:
    """
    Object representing an individual income transaction.
    """
    def __init__(self, id, user_id, amount, source, date):
        self.id = id
        self.user_id = user_id
        self.amount = amount
        self.source = source
        self.date = date

class IncomeManager:
    """
    Manages complete CRUD (Create, Read, Update, Delete) processes for Income listings.
    """
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager

    def add(self, user_id: int, amount: float, source: str, date: str) -> int:
        """Adds a new income entry into database. Returns inserted row's key index."""
        if amount <= 0:
            print("❌ Error: Income amount must be greater than zero.")
            return None
        
        query = "INSERT INTO Income (user_id, amount, source, date) VALUES (?, ?, ?, ?)"
        inserted_id = self.db.execute_query(query, (user_id, amount, source, date))
        if inserted_id:
            print(f"✅ Added Income: ${amount:.2f} from '{source}' on {date}.")
            return inserted_id
        return None

    def get_by_user(self, user_id: int) -> list:
        """Retrieves and returns all logged incomes for a given user."""
        query = "SELECT id, user_id, amount, source, date FROM Income WHERE user_id = ? ORDER BY date DESC"
        records = self.db.fetch_all(query, (user_id,))
        return [IncomeRecord(*row) for row in records]

    def update(self, income_id: int, user_id: int, amount: float, source: str, date: str) -> bool:
        """Updates details of an existing income entry."""
        if amount <= 0:
            print("❌ Error: Updated income amount must be greater than zero.")
            return False

        # Ensure the record belongs to the active user
        check = self.db.fetch_one("SELECT id FROM Income WHERE id = ? AND user_id = ?", (income_id, user_id))
        if not check:
            print("❌ Error: Income record not found or access denied.")
            return False

        query = "UPDATE Income SET amount = ?, source = ?, date = ? WHERE id = ?"
        self.db.execute_query(query, (amount, source, date, income_id))
        print(f"✅ Updated Income Entry #{income_id} successfully.")
        return True

    def delete(self, income_id: int, user_id: int) -> bool:
        """Removes an income transaction from the database."""
        # Ensure ownership
        check = self.db.fetch_one("SELECT id FROM Income WHERE id = ? AND user_id = ?", (income_id, user_id))
        if not check:
            print("❌ Error: Income record not found or access denied.")
            return False

        query = "DELETE FROM Income WHERE id = ?"
        self.db.execute_query(query, (income_id,))
        print(f"✅ Deleted Income Entry #{income_id}.")
        return True
