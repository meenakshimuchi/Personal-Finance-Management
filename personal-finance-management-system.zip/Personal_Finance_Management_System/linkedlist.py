class TransactionNode:
    """Node for Custom Singly Linked List representing a financial transaction."""
    def __init__(self, t_id: int, t_type: str, amount: float, category_or_source: str, date: str):
        self.id = t_id
        self.type = t_type                            # 'Income' or 'Expense'
        self.amount = amount
        self.category_or_source = category_or_source  # Category (Expense) or Source (Income)
        self.date = date                              # Format: YYYY-MM-DD
        self.next = None

class TransactionHistoryList:
    """
    Singly Linked List to manage dynamic transactional aggregates.
    Includes sorting and list conversion routines.
    """
    def __init__(self):
        self.head = None
        self.size = 0

    def append(self, t_id: int, t_type: str, amount: float, category_or_source: str, date: str) -> None:
        """Appends a new financial item node to the end of the list."""
        new_node = TransactionNode(t_id, t_type, amount, category_or_source, date)
        if not self.head:
            self.head = new_node
            self.size += 1
            return
        
        current = self.head
        while current.next:
            current = current.next
        current.next = new_node
        self.size += 1

    def to_python_list(self) -> list:
        """Helper to convert the custom Linked List elements into a standard python list."""
        records = []
        current = self.head
        while current:
            records.append({
                "id": current.id,
                "type": current.type,
                "amount": current.amount,
                "category_or_source": current.category_or_source,
                "date": current.date
            })
            current = current.next
        return records

    def sort_by_date_descending(self) -> None:
        """
        Performs a Bubble Sort directly on the Singly Linked List nodes.
        Orders transactions from the most recent to the oldest.
        """
        if not self.head or not self.head.next:
            return

        swapped = True
        while swapped:
            swapped = False
            curr = self.head
            while curr and curr.next:
                # Compare adjacent dates (e.g., "2026-06-18" is > "2026-05-15")
                if curr.date < curr.next.date:
                    # Swap date, type, id, amount, category_or_source values
                    curr.id, curr.next.id = curr.next.id, curr.id
                    curr.type, curr.next.type = curr.next.type, curr.type
                    curr.amount, curr.next.amount = curr.next.amount, curr.amount
                    curr.category_or_source, curr.next.category_or_source = curr.next.category_or_source, curr.category_or_source
                    curr.date, curr.next.date = curr.next.date, curr.date
                    swapped = True
                curr = curr.next

    def clear(self) -> None:
        """Removes all nodes from the linked list."""
        self.head = None
        self.size = 0

    def count(self) -> int:
        """Returns length of the linked list."""
        return self.size
