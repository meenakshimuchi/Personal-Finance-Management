import csv
from database import DatabaseManager

class TableauExporter:
    """
    Generates tailored datasets optimized for immediate ingestion in BI
    visualizers (Tableau Desktop / Tableau Public, PowerBI).
    """
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager

    def generate_csv(self, user_id: int, file_path="transactions.csv") -> bool:
        """
        Creates a CSV dataset compiling dates, custom categorizations,
        individual magnitudes, transaction designations, and running balance computations.
        """
        # Fetch Income
        incomes = self.db.fetch_all(
            "SELECT amount, source, date FROM Income WHERE user_id = ?",
            (user_id,)
        )
        # Fetch Expenses
        expenses = self.db.fetch_all(
            "SELECT amount, category, date FROM Expense WHERE user_id = ?",
            (user_id,)
        )

        all_transactions = []

        # Parse income as dictionaries
        for amt, src, dt in incomes:
            all_transactions.append({
                "date": dt,
                "category": f"Income: {src}",
                "type": "Income",
                "income": amt,
                "expense": 0.0
            })

        # Parse expenses as dictionaries
        for amt, cat, dt in expenses:
            all_transactions.append({
                "date": dt,
                "category": cat,
                "type": "Expense",
                "income": 0.0,
                "expense": amt
            })

        # Sort all transactions chronologically by Date
        all_transactions.sort(key=lambda x: x["date"])

        # Compute running balance
        running_balance = 0.0
        for tx in all_transactions:
            running_balance += tx["income"]
            running_balance -= tx["expense"]
            tx["balance"] = running_balance

        # Write to CSV
        try:
            with open(file_path, mode='w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                # CSV Headers: Date, Category, Transaction_Type, Income_Amt, Expense_Amt, Running_Balance
                writer.writerow(["Date", "Category", "Type", "Income", "Expense", "Running_Balance"])
                
                for tx in all_transactions:
                    writer.writerow([
                        tx["date"],
                        tx["category"],
                        tx["type"],
                        tx["income"],
                        tx["expense"],
                        tx["balance"]
                    ])
            print(f"📊 Tableau Data Layer created! Saved dataset to '{file_path}'.")
            return True
        except IOError as e:
            print(f"❌ CSV File I/O Error: {e}")
            return False
