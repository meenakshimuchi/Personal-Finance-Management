import sqlite3
import os

class DatabaseManager:
    """
    Handles connection, table creation, and execution of SQL queries
    for the Personal Finance Management System.
    """
    def __init__(self, db_name="finance.db"):
        self.db_name = db_name
        self.conn = None
        self.cursor = None
        self.connect()
        self.create_tables()

    def connect(self):
        """Establish connection to the SQLite database."""
        try:
            self.conn = sqlite3.connect(self.db_name)
            self.cursor = self.conn.cursor()
            # Enable foreign keys
            self.cursor.execute("PRAGMA foreign_keys = ON;")
        except sqlite3.Error as e:
            print(f"Database Connection Error: {e}")

    def create_tables(self):
        """Create the Users, Income, and Expense tables if they do not exist."""
        # 1. Users Table
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS Users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                security_question TEXT NOT NULL,
                security_answer TEXT NOT NULL
            );
        """)

        # 2. Income Table
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS Income (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount REAL NOT NULL CHECK(amount > 0),
                source TEXT NOT NULL,
                date TEXT NOT NULL, -- Format: YYYY-MM-DD
                FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
            );
        """)

        # 3. Expense Table
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS Expense (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount REAL NOT NULL CHECK(amount > 0),
                category TEXT NOT NULL CHECK(category IN ('Food', 'Shopping', 'Travel', 'Education', 'Entertainment', 'Others')),
                date TEXT NOT NULL, -- Format: YYYY-MM-DD
                FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
            );
        """)
        self.conn.commit()

    def execute_query(self, query, params=()):
        """Execute writing queries (INSERT, UPDATE, DELETE)."""
        try:
            self.cursor.execute(query, params)
            self.conn.commit()
            return self.cursor.lastrowid
        except sqlite3.Error as e:
            print(f"SQL Error: {e}")
            self.conn.rollback()
            return None

    def fetch_all(self, query, params=()):
        """Run query and return all results."""
        try:
            self.cursor.execute(query, params)
            return self.cursor.fetchall()
        except sqlite3.Error as e:
            print(f"SQL Read Error: {e}")
            return []

    def fetch_one(self, query, params=()):
        """Run query and return a single result or None."""
        try:
            self.cursor.execute(query, params)
            return self.cursor.fetchone()
        except sqlite3.Error as e:
            print(f"SQL Read Error: {e}")
            return None

    def close(self):
        """Safely close database connections."""
        if self.conn:
            self.conn.close()

if __name__ == "__main__":
    db = DatabaseManager()
    print("Database manager initialized and tables verified!")
    db.close()
