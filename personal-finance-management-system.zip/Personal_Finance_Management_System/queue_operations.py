class QueueNode:
    """Node for custom Queue implementation."""
    def __init__(self, data):
        self.data = data
        self.next = None

class RecentTransactionQueue:
    """
    Core Queue implementation (FIFO) with a fixed maximum size (capacity)
    to show rolling notifications of recent user actions.
    """
    def __init__(self, capacity=5):
        self.front = None
        self.rear = None
        self.size = 0
        self.capacity = capacity

    def enqueue(self, message: str) -> None:
        """Adds a notification message to the back of the queue (FIFO)."""
        new_node = QueueNode(message)
        
        # If queue is empty
        if self.rear is None:
            self.front = self.rear = new_node
            self.size += 1
            return

        self.rear.next = new_node
        self.rear = new_node
        self.size += 1

        # If we exceed designated capacity, dequeue the oldest notification
        if self.size > self.capacity:
            self.dequeue()

    def dequeue(self) -> str:
        """Removes and returns the oldest entry from the front of the queue."""
        if self.is_empty():
            return None
        
        removed_node = self.front
        self.front = self.front.next
        self.size -= 1

        if self.front is None:
            self.rear = None

        return removed_node.data

    def is_empty(self) -> bool:
        """Checks if there are any active notifications."""
        return self.front is None

    def display_recent_notifications(self) -> list:
        """Returns all messages currently lying inside the Queue."""
        messages = []
        curr = self.front
        while curr:
            messages.append(curr.data)
            curr = curr.next
        return messages

    def get_size(self) -> int:
        """Returns active size of queue."""
        return self.size
