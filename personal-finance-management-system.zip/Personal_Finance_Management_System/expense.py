from database import DatabaseManager

class ExpenseRecord:
    """
    Object representing an individual expense transaction.
    """
    def __init__(self, id, user_id, amount, category, date):
        self.id = id
        self.user_id = user_id
        self.amount = amount
        self.category = category
        self.date = date

class ExpenseManager:
    """
    Manages complete CRUD (Create, Read, Update, Delete) processes for Expenses.
    """
    VALID_CATEGORIES = ['Food', 'Shopping', 'Travel', 'Education', 'Entertainment', 'Others']

    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager

    def validate_category(self, category: str) -> bool:
        """Validates if category is within defined constraints."""
        return category in self.VALID_CATEGORIES

    def add(self, user_id: int, amount: float, category: str, date: str) -> int:
        """Adds a new expense to database if validated."""
        if amount <= 0:
            print("❌ Error: Expense amount must be greater than zero.")
            return None
        
        if not self.validate_category(category):
            print(f"❌ Error: Invalid Category. Choose from: {', '.join(self.VALID_CATEGORIES)}")
            return None

        query = "INSERT INTO Expense (user_id, amount, category, date) VALUES (?, ?, ?, ?)"
        inserted_id = self.db.execute_query(query, (user_id, amount, category, date))
        if inserted_id:
            print(f"✅ Added Expense: ${amount:.2f} for '{category}' on {date}.")
            return inserted_id
        return None

    def get_by_user(self, user_id: int) -> list:
        """Retrieves and returns all expenses logged for a user."""
        query = "SELECT id, user_id, amount, category, date FROM Expense WHERE user_id = ? ORDER BY date DESC"
        records = self.db.fetch_all(query, (user_id,))
        return [ExpenseRecord(*row) for row in records]

    def update(self, expense_id: int, user_id: int, amount: float, category: str, date: str) -> bool:
        """Updates details of an existing expense entry."""
        if amount <= 0:
            print("❌ Error: Updated expense amount must be greater than zero.")
            return False

        if not self.validate_category(category):
            print(f"❌ Error: Invalid Category. Choose from: {', '.join(self.VALID_CATEGORIES)}")
            return False

        # Ensure the record belongs to the active user
        check = self.db.fetch_one("SELECT id FROM Expense WHERE id = ? AND user_id = ?", (expense_id, user_id))
        if not check:
            print("❌ Error: Expense record not found or access denied.")
            return False

        query = "UPDATE Expense SET amount = ?, category = ?, date = ? WHERE id = ?"
        self.db.execute_query(query, (amount, category, date, expense_id))
        print(f"✅ Updated Expense Entry #{expense_id} successfully.")
        return True

    def delete(self, expense_id: int, user_id: int) -> bool:
        """Removes an expense entry from database."""
        # Ensure ownership
        check = self.db.fetch_one("SELECT id FROM Expense WHERE id = ? AND user_id = ?", (expense_id, user_id))
        if not check:
            print("❌ Error: Expense record not found or access denied.")
            return False

        query = "DELETE FROM Expense WHERE id = ?"
        self.db.execute_query(query, (expense_id,))
        print(f"✅ Deleted Expense Entry #{expense_id}.")
        return True
