import hashlib
from database import DatabaseManager

class AuthManager:
    """
    Manages security details including user registration, secure password
    hashing, authentication (login), and credential verification.
    """
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager

    def _hash_password(self, password: str) -> str:
        """Utility to securely hash plain text passwords using SHA-256."""
        return hashlib.sha256(password.encode()).hexdigest()

    def register(self, username: str, password: str, question: str, answer: str) -> bool:
        """
        Registers a new user inside the system.
        Hashes password securely before database entry.
        """
        # Formulate values
        hashed_pwd = self._hash_password(password)
        answer_hash = self._hash_password(answer.lower().strip())
        
        # Check if user already exists
        user_check = self.db.fetch_one("SELECT id FROM Users WHERE username = ?", (username,))
        if user_check:
            print("❌ Registration Failed: Username already exists.")
            return False

        # Insert user
        query = """
            INSERT INTO Users (username, password_hash, security_question, security_answer)
            VALUES (?, ?, ?, ?)
        """
        result = self.db.execute_query(query, (username, hashed_pwd, question, answer_hash))
        if result:
            print(f"✅ User '{username}' registered successfully!")
            return True
        return False

    def login(self, username: str, password: str) -> int:
        """
        Authenticates a user logging in.
        Returns the user_id if successful, or None if authentication fails.
        """
        hashed_pwd = self._hash_password(password)
        query = "SELECT id, password_hash FROM Users WHERE username = ?"
        record = self.db.fetch_one(query, (username,))

        if record:
            user_id, correct_hash = record
            if correct_hash == hashed_pwd:
                print(f"✅ Login Successful! Welcome, {username}.")
                return user_id
            
        print("❌ Login Failed: Invalid username or password.")
        return None

    def reset_password(self, username: str, answer: str, new_password: str) -> bool:
        """Resets user's password if security answer matches."""
        ans_hash = self._hash_password(answer.lower().strip())
        record = self.db.fetch_one("SELECT id, security_answer FROM Users WHERE username = ?", (username,))
        
        if record:
            user_id, correct_ans_hash = record
            if correct_ans_hash == ans_hash:
                new_pwd_hash = self._hash_password(new_password)
                self.db.execute_query(
                    "UPDATE Users SET password_hash = ? WHERE id = ?",
                    (new_pwd_hash, user_id)
                )
                print("✅ Password successfully reset!")
                return True
        print("❌ Verification Failed: Incorrect security credentials.")
        return False
