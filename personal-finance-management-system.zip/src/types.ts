export interface ProjectFile {
  fileName: string;
  content: string;
  badge: "Main Controller" | "DB Manager" | "SHA-256 Auth" | "Income CRUD" | "Expense CRUD" | "LIFO Stack" | "FIFO Queue" | "Singly Linked List" | "Pandas Analytics" | "Excel Exporter" | "Tableau Serializer" | "Documentation";
}

export interface ExpenseRecord {
  id: number;
  amount: number;
  category: 'Food' | 'Shopping' | 'Travel' | 'Education' | 'Entertainment' | 'Others';
  date: string;
}

export interface IncomeRecord {
  id: number;
  amount: number;
  source: string;
  date: string;
}

export interface TransactionNode {
  id: number;
  type: 'Income' | 'Expense';
  amount: number;
  categoryOrSource: string;
  date: string;
}

export interface UndoAction {
  type: 'ADD' | 'DELETE' | 'UPDATE';
  table: 'Income' | 'Expense';
  id: number;
  data: any; // Saves previous row values
}

export interface InterviewQuestion {
  question: string;
  answer: string;
  category: "Databases (SQL)" | "Data Structures (DSA)" | "Data Analytics (Pandas/Excel)" | "Programming (OOP)";
}
