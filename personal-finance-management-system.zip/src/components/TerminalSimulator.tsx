import React, { useState, useEffect } from 'react';
import { Terminal, Database, ArrowRight, CornerDownLeft, Undo2, Bell, RefreshCw, Layers, GitCommit } from 'lucide-react';
import { IncomeRecord, ExpenseRecord, UndoAction } from '../types';

interface TerminalSimulatorProps {
  onDataChange: (incomes: IncomeRecord[], expenses: ExpenseRecord[]) => void;
  incomes: IncomeRecord[];
  expenses: ExpenseRecord[];
}

export default function TerminalSimulator({ onDataChange, incomes, expenses }: TerminalSimulatorProps) {
  // Simulator database states (persisted locally in memory/localStorage)
  const [users, setUsers] = useState<any[]>(() => {
    const saved = localStorage.getItem('pfms_users');
    return saved ? JSON.parse(saved) : [
      { id: 1, name: 'admin', pass: 'admin', question: 'Favorite Framework?', answer: 'React' }
    ];
  });

  const [activeUserId, setActiveUserId] = useState<number | null>(() => {
    const saved = localStorage.getItem('pfms_active_uid');
    return saved ? Number(saved) : null;
  });

  const [activeUsername, setActiveUsername] = useState<string | null>(() => {
    return localStorage.getItem('pfms_active_username') || null;
  });

  // DSA structures
  const [stack, setStack] = useState<UndoAction[]>([]);
  const [queue, setQueue] = useState<string[]>(['🔓 System initialised. Default user "admin" is registered with password "admin".']);
  
  // Terminal I/O Streams
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    "==================================================",
    "💰 PERSONAL FINANCE MANAGEMENT SYSTEM (PFMS) 💰",
    "==================================================",
    "Initializing local database...",
    "Connecting to SQLite database (finance.db)...",
    "Verifying Users, Income, and Expense relational tables...",
    "Database connected successfully. Schema validated!",
    "--------------------------------------------------",
    "Type '1' to Register a new profile.",
    "Type '2' to Login to an active session.",
    "Type '3' to Reset a forgotten password.",
    "--------------------------------------------------"
  ]);

  const [commandInput, setCommandInput] = useState<string>('');
  
  // Active Action Prompts
  type ActiveFlow = 'NONE' | 'REGISTER_NAME' | 'REGISTER_PASS' | 'REGISTER_QUESTION' | 'REGISTER_ANSWER' |
                    'LOGIN_NAME' | 'LOGIN_PASS' |
                    'RESET_NAME' | 'RESET_ANS' | 'RESET_NEW_PASS' |
                    'ADD_INCOME_AMOUNT' | 'ADD_INCOME_SOURCE' | 'ADD_INCOME_DATE' |
                    'ADD_EXPENSE_AMOUNT' | 'ADD_EXPENSE_CAT' | 'ADD_EXPENSE_DATE' |
                    'UPDATE_RECORD_TYPE' | 'UPDATE_RECORD_ID' | 'UPDATE_RECORD_AMOUNT' | 'UPDATE_RECORD_META' | 'UPDATE_RECORD_DATE' |
                    'DELETE_RECORD_TYPE' | 'DELETE_RECORD_ID';

  const [currentFlow, setCurrentFlow] = useState<ActiveFlow>('NONE');
  
  // Temp multi-step prompt buffers
  const [registerBuffer, setRegisterBuffer] = useState({ name: '', pass: '', question: '', answer: '' });
  const [loginBuffer, setLoginBuffer] = useState({ name: '', pass: '' });
  const [resetBuffer, setResetBuffer] = useState({ name: '', answer: '', newPass: '' });
  const [incomeBuffer, setIncomeBuffer] = useState({ amount: '', source: '', date: '' });
  const [expenseBuffer, setExpenseBuffer] = useState({ amount: '', category: '', date: '' });
  const [updateBuffer, setUpdateBuffer] = useState({ type: 'Income' as 'Income'|'Expense', id: 0, amount: '', meta: '', date: '' });
  const [deleteBuffer, setDeleteBuffer] = useState({ type: 'Income' as 'Income'|'Expense', id: 0 });

  // Save changes to localstorage to preserve session data
  useEffect(() => {
    localStorage.setItem('pfms_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    if (activeUserId) {
      localStorage.setItem('pfms_active_uid', String(activeUserId));
      localStorage.setItem('pfms_active_username', activeUsername || '');
    } else {
      localStorage.removeItem('pfms_active_uid');
      localStorage.removeItem('pfms_active_username');
    }
  }, [activeUserId, activeUsername]);

  const pushQueue = (message: string) => {
    setQueue(prev => {
      const updated = [...prev, message];
      if (updated.length > 5) {
        updated.shift(); // FIFO shift
      }
      return updated;
    });
  };

  const addLog = (log: string | string[]) => {
    if (Array.isArray(log)) {
      setTerminalLogs(prev => [...prev, ...log]);
    } else {
      setTerminalLogs(prev => [...prev, log]);
    }
  };

  const handleCommandSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cmd = commandInput.trim();
    if (!cmd) return;

    addLog(`admin@BTech-Portfolio:~$ ${cmd}`);
    setCommandInput('');

    // Non-authenticated routing menu
    if (!activeUserId) {
      if (currentFlow === 'NONE') {
        if (cmd === '1') {
          addLog(["", "📝 USER PROFILE REGISTRATION", "Enter desired Username:"]);
          setCurrentFlow('REGISTER_NAME');
        } else if (cmd === '2') {
          addLog(["", "🔐 USER AUTHENTICATION", "Username:"]);
          setCurrentFlow('LOGIN_NAME');
        } else if (cmd === '3') {
          addLog(["", "🌀 PASSWORD RESET RECOVERY", "Enter target Username:"]);
          setCurrentFlow('RESET_NAME');
        } else if (cmd === '0') {
          addLog(["", "Thank you for using PFMS. Shutting down cursor thread..."]);
        } else {
          addLog("❌ Selection not recognized. Choose '1' (Register), '2' (Login), or '3' (Reset).");
        }
      } else {
        processFlowStates(cmd);
      }
    } else {
      // Authenticated routing menu
      if (currentFlow === 'NONE') {
        switch (cmd) {
          case '1':
            addLog(["", "📈 ADD INCOME TRANSACTION", "Amount ($):"]);
            setCurrentFlow('ADD_INCOME_AMOUNT');
            break;
          case '2':
            addLog(["", "📉 ADD EXPENSE TRANSACTION", "Amount ($):"]);
            setCurrentFlow('ADD_EXPENSE_AMOUNT');
            break;
          case '3':
            renderHistoryAsciiTable();
            break;
          case '4':
            addLog(["", "✏️ UPDATE EXISTING TRANSACTION", "Transaction Type to Update (Income / Expense):"]);
            setCurrentFlow('UPDATE_RECORD_TYPE');
            break;
          case '5':
            addLog(["", "🗑️ DELETE EXISTING TRANSACTION", "Transaction Type to Delete (Income / Expense):"]);
            setCurrentFlow('DELETE_RECORD_TYPE');
            break;
          case '6':
            triggerUndoLastAction();
            break;
          case '7':
            renderFinancialIndicatorsSummary();
            break;
          case '8':
            addLog(["", "📊 WRITING DESIGNED EXCEL SHEETS (OpenPyXL Pipeline)", "Generating 'finance_report.xlsx' database workbook...", "Done! Spreadsheet compiled and formatted successfully with Segui UI font."]);
            pushQueue("📊 Exported stylized excel report to 'finance_report.xlsx'.");
            break;
          case '9':
            addLog(["", "📊 WRITING TABLEAU INGESTION DATASET (CSV Pipeline)", "Generating chronological 'transactions.csv' dataset with dynamic Wallet Balances...", "Done! Data serialized successfully."]);
            pushQueue("📊 Tableau ingestion file written to 'transactions.csv'.");
            break;
          case '10':
            renderRecentSessionNotifications();
            break;
          case '0':
            logoutSession();
            break;
          default:
            addLog("❌ Menu operation index not recognized. Choose from 0 to 10.");
            break;
        }
      } else {
        processFlowStates(cmd);
      }
    }
  };

  const processFlowStates = (input: string) => {
    switch (currentFlow) {
      // REGISTRATION PIPELINE
      case 'REGISTER_NAME':
        if (!input) {
          addLog("❌ Username cannot be blank. Enter Username:");
          return;
        }
        if (users.some(u => u.name.toLowerCase() === input.toLowerCase())) {
          addLog(["❌ Username already exists. Enter another Username:", ""]);
          setCurrentFlow('NONE');
          displayGuestMenu();
          return;
        }
        setRegisterBuffer(prev => ({ ...prev, name: input }));
        addLog("Choose Password:");
        setCurrentFlow('REGISTER_PASS');
        break;

      case 'REGISTER_PASS':
        if (input.length < 4) {
          addLog("❌ Security warning: Password must exceed 3 characters. Choose Password:");
          return;
        }
        setRegisterBuffer(prev => ({ ...prev, pass: input }));
        addLog("Choose a security key Question (e.g., 'Favorite fruit?'):");
        setCurrentFlow('REGISTER_QUESTION');
        break;

      case 'REGISTER_QUESTION':
        if (!input) {
          addLog("❌ Question cannot be blank. Enter security Question:");
          return;
        }
        setRegisterBuffer(prev => ({ ...prev, question: input }));
        addLog("Private Answer (for password reset):");
        setCurrentFlow('REGISTER_ANSWER');
        break;

      case 'REGISTER_ANSWER':
        if (!input) {
          addLog("❌ Answer cannot be blank. Enter Answer:");
          return;
        }
        const newUser = {
          id: users.length + 1,
          name: registerBuffer.name,
          pass: registerBuffer.pass,
          question: registerBuffer.question,
          answer: input
        };
        setUsers(prev => [...prev, newUser]);
        addLog([`✅ Hash Encryption SHA-256 complete. User '${registerBuffer.name}' registered successfully!`, ""]);
        pushQueue(`📝 Registered new user profile: "${registerBuffer.name}"`);
        setCurrentFlow('NONE');
        displayGuestMenu();
        break;

      // LOGIN PIPELINE
      case 'LOGIN_NAME':
        const exists = users.find(u => u.name.toLowerCase() === input.toLowerCase());
        if (!exists) {
          addLog(["❌ Login Failed: Username record unrecognized.", ""]);
          setCurrentFlow('NONE');
          displayGuestMenu();
          return;
        }
        setLoginBuffer(prev => ({ ...prev, name: exists.name }));
        addLog("Password:");
        setCurrentFlow('LOGIN_PASS');
        break;

      case 'LOGIN_PASS':
        const targetUser = users.find(u => u.name === loginBuffer.name);
        if (targetUser && targetUser.pass === input) {
          setActiveUserId(targetUser.id);
          setActiveUsername(targetUser.name);
          addLog([`✅ Login Successful! Welcome, ${targetUser.name}.`, ""]);
          pushQueue(`🔓 User "${targetUser.name}" completed login validation.`);
          setCurrentFlow('NONE');
          // Wait momentarily then reload menu
          setTimeout(() => displayAuthMenu(targetUser.name), 10);
        } else {
          addLog(["❌ Login Failed: Incorrect password credential.", ""]);
          setCurrentFlow('NONE');
          displayGuestMenu();
        }
        break;

      // RESET PASSWORD PIPELINE
      case 'RESET_NAME':
        const resetUser = users.find(u => u.name.toLowerCase() === input.toLowerCase());
        if (!resetUser) {
          addLog(["❌ Password Reset: Username is not recognized.", ""]);
          setCurrentFlow('NONE');
          displayGuestMenu();
          return;
        }
        setResetBuffer(prev => ({ ...prev, name: resetUser.name }));
        addLog([`Verification Challenge Detail: "${resetUser.question}"`, "Your answer:"]);
        setCurrentFlow('RESET_ANS');
        break;

      case 'RESET_ANS':
        const verifiedUser = users.find(u => u.name === resetBuffer.name);
        if (verifiedUser && verifiedUser.answer.toLowerCase().trim() === input.toLowerCase().trim()) {
          addLog("✅ Challenge success! Enter new Password:");
          setCurrentFlow('RESET_NEW_PASS');
        } else {
          addLog(["❌ Verification Failed: Security credentials mismatch.", ""]);
          setCurrentFlow('NONE');
          displayGuestMenu();
        }
        break;

      case 'RESET_NEW_PASS':
        if (input.length < 4) {
          addLog("❌ Security warning: Password must exceed 3 letters. Enter new Password:");
          return;
        }
        setUsers(prev => prev.map(u => u.name === resetBuffer.name ? { ...u, pass: input } : u));
        addLog(["✅ Password reset completed success! New hash loaded.", ""]);
        pushQueue(`🌀 Rescued account: Reset credentials for "${resetBuffer.name}"`);
        setCurrentFlow('NONE');
        displayGuestMenu();
        break;

      // ADD INCOME PIPELINE
      case 'ADD_INCOME_AMOUNT':
        const incAmt = parseFloat(input);
        if (isNaN(incAmt) || incAmt <= 0) {
          addLog("❌ Error: Income amount must be numerical and greater than zero. Amount ($):");
          return;
        }
        setIncomeBuffer(prev => ({ ...prev, amount: String(incAmt) }));
        addLog("Source of Credit (e.g. Salary, Scholarship, Freelance):");
        setCurrentFlow('ADD_INCOME_SOURCE');
        break;

      case 'ADD_INCOME_SOURCE':
        if (!input) {
          addLog("❌ Source details required. Source of Credit:");
          return;
        }
        setIncomeBuffer(prev => ({ ...prev, source: input }));
        addLog("Date (YYYY-MM-DD or press Enter for Today):");
        setCurrentFlow('ADD_INCOME_DATE');
        break;

      case 'ADD_INCOME_DATE':
        let incDate = input.trim();
        if (!incDate) {
          incDate = new Date().toISOString().split('T')[0];
        } else if (!validateDateFormat(incDate)) {
          addLog("❌ Invalid format. Use YYYY-MM-DD. Date:");
          return;
        }
        const finalIncId = Math.max(0, ...incomes.map(i => i.id)) + 1;
        const newInc: IncomeRecord = {
          id: finalIncId,
          amount: parseFloat(incomeBuffer.amount),
          source: incomeBuffer.source,
          date: incDate
        };
        const updatedIncomes = [...incomes, newInc];
        onDataChange(updatedIncomes, expenses);

        // LIFO Stack push
        setStack(prev => [{ type: 'ADD', table: 'Income', id: finalIncId, data: null }, ...prev]);
        addLog([`✅ Added Income: $${newInc.amount.toFixed(2)} from '${newInc.source}' on ${newInc.date}.`, ""]);
        pushQueue(`📈 Added: $${newInc.amount.toFixed(2)} Income from "${newInc.source}" on ${newInc.date}`);
        setCurrentFlow('NONE');
        displayAuthMenu();
        break;

      // ADD EXPENSE PIPELINE
      case 'ADD_EXPENSE_AMOUNT':
        const expAmt = parseFloat(input);
        if (isNaN(expAmt) || expAmt <= 0) {
          addLog("❌ Error: Expense amount must be numerical and greater than zero. Amount ($):");
          return;
        }
        setExpenseBuffer(prev => ({ ...prev, amount: String(expAmt) }));
        addLog(`Select Category (Food, Shopping, Travel, Education, Entertainment, Others):`);
        setCurrentFlow('ADD_EXPENSE_CAT');
        break;

      case 'ADD_EXPENSE_CAT':
        const cats = ['Food', 'Shopping', 'Travel', 'Education', 'Entertainment', 'Others'];
        const formattedCat = input.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' ');
        if (!cats.includes(formattedCat)) {
          addLog(`❌ Invalid Category. Choose from: ${cats.join(', ')}:`);
          return;
        }
        setExpenseBuffer(prev => ({ ...prev, category: formattedCat as any }));
        addLog("Date (YYYY-MM-DD or press Enter for Today):");
        setCurrentFlow('ADD_EXPENSE_DATE');
        break;

      case 'ADD_EXPENSE_DATE':
        let expDate = input.trim();
        if (!expDate) {
          expDate = new Date().toISOString().split('T')[0];
        } else if (!validateDateFormat(expDate)) {
          addLog("❌ Invalid date. Use YYYY-MM-DD. Date:");
          return;
        }
        const finalExpId = Math.max(0, ...expenses.map(e => e.id)) + 1;
        const newExp: ExpenseRecord = {
          id: finalExpId,
          amount: parseFloat(expenseBuffer.amount),
          category: expenseBuffer.category as any,
          date: expDate
        };
        const updatedExpenses = [...expenses, newExp];
        onDataChange(incomes, updatedExpenses);

        // LIFO Stack push
        setStack(prev => [{ type: 'ADD', table: 'Expense', id: finalExpId, data: null }, ...prev]);
        addLog([`✅ Added Expense: $${newExp.amount.toFixed(2)} for '${newExp.category}' on ${newExp.date}.`, ""]);
        pushQueue(`📉 Added: $${newExp.amount.toFixed(2)} Expense for "${newExp.category}" on ${newExp.date}`);
        setCurrentFlow('NONE');
        displayAuthMenu();
        break;

      // UPDATE PIPELINE
      case 'UPDATE_RECORD_TYPE':
        const uptType = input.trim().toLowerCase();
        if (uptType !== 'income' && uptType !== 'expense') {
          addLog("❌ Selection Error. Must enter 'Income' or 'Expense':");
          return;
        }
        const resolvedType = uptType === 'income' ? 'Income' : 'Expense';
        setUpdateBuffer(prev => ({ ...prev, type: resolvedType }));
        addLog(`Enter existing ${resolvedType} Transaction ID to update:`);
        setCurrentFlow('UPDATE_RECORD_ID');
        break;

      case 'UPDATE_RECORD_ID':
        const targetId = parseInt(input);
        if (isNaN(targetId)) {
          addLog("❌ ID must be a numerical integer value. Transaction ID:");
          return;
        }
        // Verify existence of record
        if (updateBuffer.type === 'Income') {
          const rec = incomes.find(i => i.id === targetId);
          if (!rec) {
            addLog([`❌ Income ID #${targetId} not found in user database tables.`, ""]);
            setCurrentFlow('NONE');
            displayAuthMenu();
            return;
          }
          setUpdateBuffer(prev => ({ ...prev, id: targetId, amount: String(rec.amount), meta: rec.source, date: rec.date }));
        } else {
          const rec = expenses.find(e => e.id === targetId);
          if (!rec) {
            addLog([`❌ Expense ID #${targetId} not found in user database tables.`, ""]);
            setCurrentFlow('NONE');
            displayAuthMenu();
            return;
          }
          setUpdateBuffer(prev => ({ ...prev, id: targetId, amount: String(rec.amount), meta: rec.category, date: rec.date }));
        }

        addLog(`Record targeted successfully. Enter new Amount ($):`);
        setCurrentFlow('UPDATE_RECORD_AMOUNT');
        break;

      case 'UPDATE_RECORD_AMOUNT':
        const newAmt = parseFloat(input);
        if (isNaN(newAmt) || newAmt <= 0) {
          addLog("❌ Amount must be greater than zero. Amount ($):");
          return;
        }
        setUpdateBuffer(prev => ({ ...prev, amount: String(newAmt) }));
        if (updateBuffer.type === 'Income') {
          addLog("Enter new Source Descriptor:");
        } else {
          addLog("Enter new Category (Food, Shopping, Travel, Education, Entertainment, Others):");
        }
        setCurrentFlow('UPDATE_RECORD_META');
        break;

      case 'UPDATE_RECORD_META':
        if (!input) {
          addLog("❌ Input required. Enter details:");
          return;
        }
        if (updateBuffer.type === 'Expense') {
          const catsMatch = ['Food', 'Shopping', 'Travel', 'Education', 'Entertainment', 'Others'];
          const fmtCat = input.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' ');
          if (!catsMatch.includes(fmtCat)) {
            addLog(`❌ Invalid Category choice. Choose from ${catsMatch.join(', ')}:`);
            return;
          }
          setUpdateBuffer(prev => ({ ...prev, meta: fmtCat }));
        } else {
          setUpdateBuffer(prev => ({ ...prev, meta: input }));
        }
        addLog("Enter new Date (YYYY-MM-DD):");
        setCurrentFlow('UPDATE_RECORD_DATE');
        break;

      case 'UPDATE_RECORD_DATE':
        if (!validateDateFormat(input)) {
          addLog("❌ Invalid date. Use format YYYY-MM-DD. Enter Date:");
          return;
        }
        // Save current record to undo stack & commit DB updates
        if (updateBuffer.type === 'Income') {
          const prevRec = incomes.find(i => i.id === updateBuffer.id);
          setStack(prev => [{ type: 'UPDATE', table: 'Income', id: updateBuffer.id, data: { ...prevRec } }, ...prev]);
          
          onDataChange(
            incomes.map(i => i.id === updateBuffer.id ? { ...i, amount: parseFloat(updateBuffer.amount), source: updateBuffer.meta, date: input } : i),
            expenses
          );
        } else {
          const prevRec = expenses.find(e => e.id === updateBuffer.id);
          setStack(prev => [{ type: 'UPDATE', table: 'Expense', id: updateBuffer.id, data: { ...prevRec } }, ...prev]);
          
          onDataChange(
            incomes,
            expenses.map(e => e.id === updateBuffer.id ? { ...e, amount: parseFloat(updateBuffer.amount), category: updateBuffer.meta as any, date: input } : e)
          );
        }

        addLog([`✅ Updated ${updateBuffer.type} Entry #${updateBuffer.id} successfully!`, ""]);
        pushQueue(`✏️ Updated ${updateBuffer.type} ID #${updateBuffer.id} to new total $${parseFloat(updateBuffer.amount).toFixed(2)}`);
        setCurrentFlow('NONE');
        displayAuthMenu();
        break;

      // DELETE PIPELINE
      case 'DELETE_RECORD_TYPE':
        const dType = input.trim().toLowerCase();
        if (dType !== 'income' && dType !== 'expense') {
          addLog("❌ Must selection 'Income' or 'Expense' to delete:");
          return;
        }
        const delTable = dType === 'income' ? 'Income' : 'Expense';
        setDeleteBuffer(prev => ({ ...prev, type: delTable }));
        addLog(`Enter target ${delTable} ID to permanently remove:`);
        setCurrentFlow('DELETE_RECORD_ID');
        break;

      case 'DELETE_RECORD_ID':
        const delId = parseInt(input);
        if (isNaN(delId)) {
          addLog("❌ ID must be integer numeric. ID Value:");
          return;
        }

        if (deleteBuffer.type === 'Income') {
          const prev = incomes.find(i => i.id === delId);
          if (!prev) {
            addLog([`❌ Record Income ID #${delId} not discovered in sql registries.`, ""]);
            setCurrentFlow('NONE');
            displayAuthMenu();
            return;
          }
          setStack(prevStack => [{ type: 'DELETE', table: 'Income', id: delId, data: { ...prev } }, ...prevStack]);
          onDataChange(incomes.filter(i => i.id !== delId), expenses);
        } else {
          const prev = expenses.find(e => e.id === delId);
          if (!prev) {
            addLog([`❌ Record Expense ID #${delId} not discovered in sql registries.`, ""]);
            setCurrentFlow('NONE');
            displayAuthMenu();
            return;
          }
          setStack(prevStack => [{ type: 'DELETE', table: 'Expense', id: delId, data: { ...prev } }, ...prevStack]);
          onDataChange(incomes, expenses.filter(e => e.id !== delId));
        }

        addLog([`✅ Deleted ${deleteBuffer.type} Entry #${delId} from transactional records.`, ""]);
        pushQueue(`🗑️ Deleted ${deleteBuffer.type} ID #${delId} successfully.`);
        setCurrentFlow('NONE');
        displayAuthMenu();
        break;
    }
  };

  const validateDateFormat = (date: string): boolean => {
    const reg = /^\d{4}-\d{2}-\d{2}$/;
    if (!reg.test(date)) return false;
    const d = new Date(date);
    return !isNaN(d.getTime());
  };

  const logoutSession = () => {
    pushQueue(`🔐 Terminated session. "${activeUsername}" logged out.`);
    addLog([`🔐 Terminating Session. User '${activeUsername}' logged out.`, ""]);
    setActiveUserId(null);
    setActiveUsername(null);
    setStack([]);
    setCurrentFlow('NONE');
    setTimeout(() => displayGuestMenu(), 10);
  };

  const displayGuestMenu = () => {
    addLog([
      "==================================================",
      "💰 PERSONAL FINANCE MANAGEMENT SYSTEM (PFMS) 💰",
      "==================================================",
      "1. Register User Profile",
      "2. Login to Active Session",
      "3. Reset Forgotten Password",
      "0. Shut Down Application",
      "--------------------------------------------------",
      "Enter option index:"
    ]);
  };

  const displayAuthMenu = (uname: string = activeUsername || '') => {
    addLog([
      "==================================================",
      "💰 PERSONAL FINANCE MANAGEMENT SYSTEM (PFMS) 💰",
      "==================================================",
      `🔒 Session Active: ${uname} (User ID: ${activeUserId})`,
      "--------------------------------------------------",
      "1. Add Income Source",
      "2. Add Expense Ledger",
      "3. View Sorted Transactions History (Linked List)",
      "4. Update Existing Record",
      "5. Delete Existing Record",
      "6. Undo Last Database Action (Stack)",
      "7. Financial Indicators Summary (Pandas)",
      "8. Export stylized Report to MS Excel (OpenPyXL)",
      "9. Compile Tableau Data Layer (CSV)",
      "10. View Recent Session Notifications (Queue)",
      "0. Terminate User Session / Logout",
      "--------------------------------------------------",
      "Enter option index:"
    ]);
  };

  // Traversal of custom linked lists sorting
  const renderHistoryAsciiTable = () => {
    const combined = getSortedTransactionsHistory();
    if (combined.length === 0) {
      addLog(["", "📜 TRANSACTION HISTORY (Sorted Linked List traversal)", "📭 Empty Ledger: No financial items entered in active session.", ""]);
      return;
    }

    const output = [
      "",
      "📜 TRANSACTION HISTORY (Sorted Linked List traversal with embedded bubble sort)",
      "-----------------------------------------------------------------",
      "TX ID    | Type     | Amount ($)   | Category/Source      | Date      ",
      "-----------------------------------------------------------------",
      ...combined.map(t => {
        const id_f = String(t.id).padEnd(8);
        const type_f = t.type.padEnd(8);
        const amt_f = `$${t.amount.toFixed(2)}`.padEnd(12);
        const label_f = t.categoryOrSource.slice(0, 20).padEnd(20);
        const date_f = t.date;
        return `${id_f} | ${type_f} | ${amt_f} | ${label_f} | ${date_f}`;
      }),
      "-----------------------------------------------------------------",
      `Total Traversed Node Records: ${combined.length}`,
      ""
    ];
    addLog(output);
  };

  // Aggregates sorted historically
  const getSortedTransactionsHistory = () => {
    const combined: any[] = [
      ...incomes.map(i => ({ id: i.id, type: 'Income', amount: i.amount, categoryOrSource: i.source, date: i.date })),
      ...expenses.map(e => ({ id: e.id, type: 'Expense', amount: e.amount, categoryOrSource: e.category, date: e.date }))
    ];

    // Bubbles sort on list array mimicking linked list date sort
    for (let i = 0; i < combined.length; i++) {
      for (let j = 0; j < combined.length - 1 - i; j++) {
        if (combined[j].date < combined[j + 1].date) {
          const temp = combined[j];
          combined[j] = combined[j + 1];
          combined[j + 1] = temp;
        }
      }
    }
    return combined;
  };

  // Reversing of stack actions
  const triggerUndoLastAction = () => {
    if (stack.length === 0) {
      addLog(["", "↩️ UNDO LAST SESSION TRANSACTION (Action Stack Pop)", "📭 Nothing to undo: No recent transactions recorded in this session.", ""]);
      return;
    }

    const action = stack[0];
    const remainingStack = stack.slice(1);
    setStack(remainingStack);

    if (action.type === 'ADD') {
      if (action.table === 'Income') {
        onDataChange(incomes.filter(i => i.id !== action.id), expenses);
      } else {
        onDataChange(incomes, expenses.filter(e => e.id !== action.id));
      }
      addLog([
        "",
        "↩️ UNDO LAST SESSION TRANSACTION (Action Stack Pop)",
        `↩️ Undo Successful: Removed newly added ${action.table} entry (ID: ${action.id}).`,
        ""
      ]);
      pushQueue(`↩️ Undo Completed: Reverted addition of ${action.table} ID #${action.id}`);
    } else if (action.type === 'DELETE') {
      if (action.table === 'Income') {
        onDataChange([...incomes, action.data], expenses);
      } else {
        onDataChange(incomes, [...expenses, action.data]);
      }
      addLog([
        "",
        "↩️ UNDO LAST SESSION TRANSACTION (Action Stack Pop)",
        `↩️ Undo Successful: Restored deleted ${action.table} entry (ID: ${action.id}).`,
        ""
      ]);
      pushQueue(`↩️ Undo Completed: Restored deleted ${action.table} ID #${action.id}`);
    } else if (action.type === 'UPDATE') {
      if (action.table === 'Income') {
        onDataChange(
          incomes.map(i => i.id === action.id ? { ...action.data } : i),
          expenses
        );
      } else {
        onDataChange(
          incomes,
          expenses.map(e => e.id === action.id ? { ...action.data } : e)
        );
      }
      addLog([
        "",
        "↩️ UNDO LAST SESSION TRANSACTION (Action Stack Pop)",
        `↩️ Undo Successful: Restored updated ${action.table} entry to previous values (ID: ${action.id}).`,
        ""
      ]);
      pushQueue(`↩️ Undo Completed: Reverted modification of ${action.table} ID #${action.id}`);
    }
  };

  // Statistics summaries
  const renderFinancialIndicatorsSummary = () => {
    const totInc = incomes.reduce((acc, i) => acc + i.amount, 0);
    const totExp = expenses.reduce((acc, e) => acc + e.amount, 0);
    const bal = totInc - totExp;
    const savPct = totInc > 0 ? ((totInc - totExp) / totInc) * 100 : 0;
    
    // Monthly average
    const months = Array.from(new Set(expenses.map(e => e.date.substring(0, 7))));
    const monthlyAverage = months.length > 0 ? totExp / months.length : totExp;

    // Highest category
    const catTotals: { [key: string]: number } = {};
    expenses.forEach(e => {
      catTotals[e.category] = (catTotals[e.category] || 0) + e.amount;
    });
    let maxCatName = 'N/A';
    let maxCatVal = 0;
    Object.keys(catTotals).forEach(c => {
      if (catTotals[c] > maxCatVal) {
        maxCatVal = catTotals[c];
        maxCatName = c;
      }
    });

    const output = [
      "",
      "📊 DATA ANALYSIS & KEY PERFORMANCE INDICATORS (Pandas evaluations)",
      "--------------------------------------------------",
      `💸 Cumulative Registered Income: $${totInc.toFixed(2)}`,
      `🛒 Cumulative Logged Expenses:   $${totExp.toFixed(2)}`,
      `💼 Current Ledger Balance:       $${bal.toFixed(2)}`,
      `☘️ Cumulative Savings Margin:    ${totInc > 0 ? Math.max(0, savPct).toFixed(1) : '0.0'}%`,
      `📉 Average Expenditure/Month:    $${monthlyAverage.toFixed(2)}`,
      `🔥 Categories with Most Costs:   ${maxCatName} ($${maxCatVal.toFixed(2)})`,
      "--------------------------------------------------",
      ""
    ];
    addLog(output);
  };

  const renderRecentSessionNotifications = () => {
    const lines = [
      "",
      "🔔 RECENT ACTIVITIES WORKSPACE QUEUE (FIFO)",
      "--------------------------------------------------",
      ...queue.map((q, i) => `  [#${i+1}] ${q}`),
      "--------------------------------------------------",
      ""
    ];
    addLog(lines);
  };

  // Helper extension wrapper functions to type specific commands
  const simulateCommandType = (cmd: string) => {
    setCommandInput(cmd);
  };

  const formatLlist = () => {
    return getSortedTransactionsHistory();
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 leading-6">
      {/* Real Interactive Terminal Interface */}
      <div className="xl:col-span-8 flex flex-col bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-xs">
        <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Terminal className="h-4.5 w-4.5 text-indigo-400" />
            <span className="text-xs font-mono font-bold text-slate-300">Python CLI Console Simulator</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-[10px] text-slate-400 font-mono">finance.db active</span>
          </div>
        </div>

        {/* LOG Output Screen */}
        <div className="flex-1 p-4 h-[350px] overflow-y-auto font-mono text-[11px] text-slate-300 space-y-1 select-text bg-slate-950">
          {terminalLogs.map((log, idx) => (
            <div key={idx} className={
              log.startsWith('admin@') ? 'text-indigo-400 font-bold mt-2' :
              log.startsWith('✅') || log.startsWith('↩️') ? 'text-emerald-400 font-semibold' :
              log.startsWith('❌') ? 'text-rose-400 font-semibold' :
              log.startsWith('💰') || log.startsWith('🔒') ? 'text-amber-300 font-bold' :
              'text-slate-300'
            }>
              {log}
            </div>
          ))}
        </div>

        {/* Console Command Inputs Bar */}
        <form onSubmit={handleCommandSubmit} className="flex border-t border-slate-800 bg-slate-905">
          <div className="flex items-center px-4 text-xs font-mono text-indigo-400 font-bold border-r border-slate-800 bg-slate-900/50">
            {activeUsername ? `${activeUsername}@system:~$` : 'system:~$'}
          </div>
          <input
            type="text"
            value={commandInput}
            onChange={(e) => setCommandInput(e.target.value)}
            placeholder={
              currentFlow !== 'NONE'
                ? "Enter prompted parameter value..."
                : "Type option index (e.g. 1, 2, 7, 0) and press Enter..."
            }
            className="flex-1 px-4 py-3 bg-slate-950 text-slate-200 font-mono text-xs focus:outline-hidden"
          />
          <button
            type="submit"
            className="px-4 bg-indigo-600/10 hover:bg-indigo-600/20 text-indigo-400 border-l border-slate-800 text-xs font-mono font-bold flex items-center gap-1 cursor-pointer"
          >
            Send <CornerDownLeft className="h-3 w-3" />
          </button>
        </form>

        {/* Quick Simulated Command Shortcuts Card */}
        <div className="p-3 bg-slate-900/40 border-t border-slate-800 flex items-center justify-between gap-2 overflow-x-auto">
          <span className="text-[10px] text-slate-400 font-mono whitespace-nowrap shrink-0">Command Suggestions:</span>
          <div className="flex gap-1.5 overflow-x-auto pb-1 md:pb-0">
            {activeUserId ? (
              <>
                <button onClick={() => simulateCommandType('1')} className="px-2 py-0.5 bg-slate-800 text-slate-300 text-[10px] font-mono hover:bg-slate-700 hover:text-white rounded transition-colors whitespace-nowrap">1: Add Income</button>
                <button onClick={() => simulateCommandType('2')} className="px-2 py-0.5 bg-slate-800 text-slate-300 text-[10px] font-mono hover:bg-slate-700 hover:text-white rounded transition-colors whitespace-nowrap">2: Add Expense</button>
                <button onClick={() => simulateCommandType('3')} className="px-2 py-0.5 bg-slate-800 text-slate-300 text-[10px] font-mono hover:bg-slate-700 hover:text-white rounded transition-colors whitespace-nowrap">3: View List</button>
                <button onClick={() => simulateCommandType('6')} className="px-2 py-0.5 bg-slate-800 text-slate-300 text-[10px] font-mono hover:bg-slate-700 hover:text-white rounded transition-colors whitespace-nowrap">6: Undo LIFO</button>
                <button onClick={() => simulateCommandType('7')} className="px-2 py-0.5 bg-slate-800 text-slate-300 text-[10px] font-mono hover:bg-slate-700 hover:text-white rounded transition-colors whitespace-nowrap">7: Summary</button>
                <button onClick={() => simulateCommandType('8')} className="px-2 py-0.5 bg-slate-800 text-slate-300 text-[10px] font-mono hover:bg-slate-700 hover:text-white rounded transition-colors whitespace-nowrap">8: Excel</button>
                <button onClick={() => simulateCommandType('9')} className="px-2 py-0.5 bg-slate-800 text-slate-300 text-[10px] font-mono hover:bg-slate-700 hover:text-white rounded transition-colors whitespace-nowrap">9: Tableau</button>
                <button onClick={() => simulateCommandType('0')} className="px-2 py-0.5 bg-rose-950/40 text-rose-300 text-[10px] font-mono hover:bg-rose-900/30 rounded border border-rose-900/30 transition-colors whitespace-nowrap">Logout</button>
              </>
            ) : (
              <>
                <button onClick={() => simulateCommandType('2')} className="px-2.5 py-0.5 bg-slate-800 text-slate-305 text-[10px] font-mono hover:bg-slate-700 hover:text-white rounded transition-colors whitespace-nowrap">2: Quick Login</button>
                <button onClick={() => simulateCommandType('1')} className="px-2.5 py-0.5 bg-slate-800 text-slate-305 text-[10px] font-mono hover:bg-slate-700 hover:text-white rounded transition-colors whitespace-nowrap">1: Register</button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Live DSA Memory Tracks Panel */}
      <div className="xl:col-span-4 flex flex-col gap-5">
        
        {/* LIFO STACK MONITOR */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm flex-1 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-2.5 border-b border-slate-800 mb-3">
              <Layers className="h-4.5 w-4.5 text-rose-400" />
              <span className="text-xs font-bold text-slate-300 uppercase tracking-widest">Undo Stack (LIFO)</span>
            </div>
            <p className="text-[10px] text-slate-500 mb-2 leading-normal">
              Accumulates updates, deletions, or insertions into sequential nodes. Popping reverses actions chronologically inside <strong>SQL check threads</strong>.
            </p>
            <div className="space-y-1 max-h-[140px] overflow-y-auto">
              {stack.length === 0 ? (
                <div className="text-center py-6 text-[10px] text-slate-500 border border-dashed border-slate-840 rounded bg-slate-950/20">
                  📭 Temporary Stack is empty.
                </div>
              ) : (
                stack.map((item, idx) => (
                  <div key={idx} className={`p-2 rounded text-[10px] font-mono flex items-center justify-between ${
                    idx === 0 ? 'bg-rose-950/40 border border-rose-900/55 text-rose-200 font-bold' : 'bg-slate-955 text-slate-400 border border-slate-800/60'
                  }`}>
                    <span>
                      {idx === 0 && <span className="text-rose-500 mr-1 animate-pulse">● [Top]</span>}
                      {item.type} {item.table} (ID: {item.id})
                    </span>
                    <span className="text-[9px] opacity-60">Node #{stack.length - idx}</span>
                  </div>
                ))
              )}
            </div>
          </div>
          {stack.length > 0 && (
            <button
              onClick={triggerUndoLastAction}
              className="mt-3 w-full py-2 bg-rose-950/20 border border-rose-905 text-rose-300 text-[10px] font-semibold font-mono rounded flex items-center justify-center gap-1 cursor-pointer"
            >
              <Undo2 className="h-3.5 w-3.5" /> Force Pop & Undo SQL
            </button>
          )}
        </div>

        {/* FIFO ROLLING QUEUE MONITOR */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm flex-1">
          <div className="flex items-center gap-2 pb-2.5 border-b border-slate-800 mb-3">
            <Bell className="h-4.5 w-4.5 text-indigo-400" />
            <span className="text-xs font-bold text-slate-300 uppercase tracking-widest">Notification Queue (FIFO)</span>
          </div>
          <p className="text-[10px] text-slate-500 mb-3 leading-normal">
            Stores session transactions inside a fixed rolling 5-sized buffer logic. Older warnings are discarded first (FIFO).
          </p>
          <div className="space-y-1 max-h-[140px] overflow-y-auto">
            {queue.map((item, idx) => {
              const isFront = idx === 0;
              const isRear = idx === queue.length - 1;
              return (
                <div key={idx} className={`p-2 rounded text-[10px] font-mono border ${
                  isFront ? 'bg-indigo-950/40 border-indigo-900 text-indigo-200' :
                  isRear ? 'bg-emerald-950/20 border-emerald-900/30 text-slate-400' :
                  'bg-slate-950/40 border-slate-800/80 text-slate-450'
                }`}>
                  <div className="flex items-center justify-between">
                    <span className="truncate pr-1">{item}</span>
                    <span className="text-[8px] font-bold px-1 rounded uppercase shrink-0 scale-90 bg-slate-800">
                      {isFront && 'Front'}
                      {isRear && 'Rear'}
                      {!isFront && !isRear && `Idx ${idx}`}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

      {/* SINGLY LINKED LIST DIAGRAM CHAIN */}
      <div className="col-span-1 xl:col-span-12 bg-white rounded-xl shadow-xs border border-slate-100 p-5 mt-2">
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-100 mb-4 bg-white">
          <div className="flex items-center gap-2">
            <GitCommit className="h-5 w-5 text-indigo-600" id="llist-node-icon" />
            <h3 className="text-sm font-semibold text-slate-800" id="llist-visualizer-title">
              Logical Singly Linked List Data Chain Visualizer
            </h3>
          </div>
          <span className="text-[10px] bg-slate-100 border border-slate-200 px-2 py-0.5 rounded-full text-slate-500 font-mono">
            Sorted Chronologically: Date DESC
          </span>
        </div>
        <p className="text-xs text-slate-400 mb-5 leading-relaxed">
          The diagram below represents the custom Linked List populated from database tables in memory sorted using a pointer-based **Bubble Sort algorithm**.
        </p>

        {/* Dynamic linked list row mapping with indicators */}
        <div className="flex items-center gap-3 overflow-x-auto py-4 px-2 bg-slate-50/50 rounded-lg border border-slate-100 scrollbar-thin">
          <div className="flex items-center gap-1 bg-indigo-6500 text-indigo-102 font-mono text-[10px] font-bold px-2 py-3 border border-indigo-200 rounded-md shrink-0">
            HEAD
          </div>
          <ArrowRight className="h-4 w-4 text-slate-350 shrink-0" />

          {formatLlist().length === 0 ? (
            <div className="text-xs text-slate-400 font-mono py-1">
              [No Nodes Enregistered in Session]
            </div>
          ) : (
            formatLlist().map((node, i) => (
              <React.Fragment key={i}>
                <div className={`p-3 rounded-lg border flex flex-col gap-1.5 font-mono text-[10px] text-slate-705 shrink-0 select-none ${
                    node.type === 'Income' ? 'bg-emerald-50 border-emerald-200' : 'bg-rose-50 border-rose-200'
                  }`}
                  style={{ width: '150px' }}
                >
                  <div className="flex justify-between font-bold">
                    <span>Node #{i + 1}</span>
                    <span className={node.type === 'Income' ? 'text-emerald-700' : 'text-rose-700'}>
                      {node.type}
                    </span>
                  </div>
                  <div className="border-t border-dashed border-slate-200/60 my-0.5" />
                  <div className="text-slate-600">ID: <span className="font-bold text-slate-800">{node.id}</span></div>
                  <div className="text-slate-600">Amt: <span className="font-bold text-slate-800">${node.amount.toFixed(2)}</span></div>
                  <div className="text-slate-600 truncate">Desc: <span className="font-bold text-slate-800">{node.categoryOrSource}</span></div>
                  <div className="text-slate-600">Date: <span className="font-bold text-slate-800 text-[9px]">{node.date}</span></div>
                  <div className="border-t border-dashed border-slate-200/60 my-0.5" />
                  <div className="text-center font-bold text-indigo-600/60 font-sans text-[8px] tracking-wider">
                    Next {`➔`} {i === formatLlist().length - 1 ? 'NULL' : `Node #${i + 2}`}
                  </div>
                </div>
                <ArrowRight className="h-4 w-4 text-slate-300 shrink-0" />
              </React.Fragment>
            ))
          )}
          <div className="flex items-center gap-1 bg-slate-200 text-slate-600 font-mono text-[10px] font-bold px-2 py-3 border border-slate-300 rounded-md shrink-0">
            NULL
          </div>
        </div>
      </div>
    </div>
  );
}
