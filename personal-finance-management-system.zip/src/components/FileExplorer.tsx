import React, { useState, useEffect } from 'react';
import { FileCode, FileText, ChevronRight, FolderMinus, Save, Download, RefreshCw, CheckCircle, AlertCircle } from 'lucide-react';
import { ProjectFile } from '../types';

export default function FileExplorer() {
  const [files, setFiles] = useState<ProjectFile[]>([]);
  const [selectedFile, setSelectedFile] = useState<ProjectFile | null>(null);
  const [editedContent, setEditedContent] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveStatus, setSaveStatus] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Get matching badge/meta description for each file
  const getFileMetadata = (fileName: string): ProjectFile['badge'] => {
    switch (fileName) {
      case 'main.py': return 'Main Controller';
      case 'database.py': return 'DB Manager';
      case 'login.py': return 'SHA-256 Auth';
      case 'income.py': return 'Income CRUD';
      case 'expense.py': return 'Expense CRUD';
      case 'stack_operations.py': return 'LIFO Stack';
      case 'queue_operations.py': return 'FIFO Queue';
      case 'linkedlist.py': return 'Singly Linked List';
      case 'analysis.py': return 'Pandas Analytics';
      case 'excel_export.py': return 'Excel Exporter';
      case 'tableau_data.py': return 'Tableau Serializer';
      case 'README.md': return 'Documentation';
      default: return 'Documentation';
    }
  };

  // Fetch all physical python project files from server dir
  const fetchFiles = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/project/files');
      if (response.ok) {
        const data = await response.json();
        const formattedFiles = data.files.map((f: any) => ({
          fileName: f.fileName,
          content: f.content,
          badge: getFileMetadata(f.fileName)
        }));
        setFiles(formattedFiles);

        // Select main.py by default
        const mainPy = formattedFiles.find((f: any) => f.fileName === 'main.py');
        if (mainPy) {
          setSelectedFile(mainPy);
          setEditedContent(mainPy.content);
        } else if (formattedFiles.length > 0) {
          setSelectedFile(formattedFiles[0]);
          setEditedContent(formattedFiles[0].content);
        }
      }
    } catch (e) {
      console.error('Failed to query files from workspace api', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFiles();
  }, []);

  const handleSelectFile = (file: ProjectFile) => {
    setSelectedFile(file);
    setEditedContent(file.content);
    setSaveStatus(null);
  };

  const handleSave = async () => {
    if (!selectedFile) return;
    setIsSaving(true);
    setSaveStatus(null);

    try {
      const response = await fetch('/api/project/files/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          fileName: selectedFile.fileName,
          content: editedContent
        }),
      });

      if (response.ok) {
        setSaveStatus({ type: 'success', text: `Saved changes to ${selectedFile.fileName}!` });
        // Update local state list
        setFiles(prev => prev.map(f => f.fileName === selectedFile.fileName ? { ...f, content: editedContent } : f));
      } else {
        const err = await response.json();
        setSaveStatus({ type: 'error', text: err.error || "Failed to commit changes." });
      }
    } catch (err: any) {
      setSaveStatus({ type: 'error', text: err.message || "Network write error." });
    } finally {
      setIsSaving(false);
    }
  };

  const handleZipDownload = () => {
    window.open('/api/project/download', '_blank');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[560px]">
      {/* File Explorer Tree Panel */}
      <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
            <div className="flex items-center gap-2">
              <FolderMinus className="h-5 w-5 text-indigo-400" id="dir-icon" />
              <span className="text-xs font-bold text-slate-300 uppercase tracking-widest">Workspace Explorer</span>
            </div>
            <button
              onClick={fetchFiles}
              className="p-1 rounded-md hover:bg-slate-800 text-slate-400 hover:text-slate-300 transition-colors"
              title="Refresh Files"
            >
              <RefreshCw className="h-4 w-4" id="refresh-files-icon" />
            </button>
          </div>

          {loading ? (
            <div className="flex flex-col items-center justify-center py-12 gap-2 text-slate-500">
              <RefreshCw className="h-6 w-6 animate-spin text-indigo-400" />
              <span className="text-xs">Loading tree structure...</span>
            </div>
          ) : (
            <div className="space-y-1.5 max-h-[420px] overflow-y-auto pr-1">
              {files.map((file) => {
                const isSelected = selectedFile?.fileName === file.fileName;
                const isPy = file.fileName.endsWith('.py');
                return (
                  <button
                    key={file.fileName}
                    onClick={() => handleSelectFile(file)}
                    className={`w-full flex items-center justify-between p-2.5 rounded-lg text-left transition-all ${
                      isSelected
                        ? 'bg-indigo-600/10 border border-indigo-500/20 text-indigo-200'
                        : 'border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      {isPy ? (
                        <FileCode className={`h-4.5 w-4.5 ${isSelected ? 'text-indigo-400' : 'text-slate-500'}`} />
                      ) : (
                        <FileText className={`h-4.5 w-4.5 ${isSelected ? 'text-violet-400' : 'text-slate-500'}`} />
                      )}
                      <span className="text-xs truncate font-mono">{file.fileName}</span>
                    </div>
                    <span className="text-[10px] scale-90 px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 opacity-80 shrink-0 font-medium">
                      {file.badge}
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* ZIP Downloader Panel */}
        <div className="mt-4 pt-4 border-t border-slate-800">
          <button
            onClick={handleZipDownload}
            className="w-full flex items-center justify-center gap-2.5 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow-md transition-all cursor-pointer"
          >
            <Download className="h-4.5 w-4.5" id="zip-download-icon" />
            Download Complete Project ZIP
          </button>
          <p className="text-[10px] text-slate-500 mt-2 text-center">
            Extract zip and run locally using "python main.py"
          </p>
        </div>
      </div>

      {/* Code Editor Panel */}
      <div className="lg:col-span-8 flex flex-col bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-md">
        {selectedFile ? (
          <>
            {/* Header metadata bar */}
            <div className="flex items-center justify-between px-4 py-3 bg-slate-900 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <ChevronRight className="h-4 w-4 text-emerald-400" />
                <span className="text-xs font-mono font-bold text-slate-200">
                  {selectedFile.fileName}
                </span>
                <span className="text-[10px] px-2 py-0.5 bg-slate-800 rounded-full text-slate-400 border border-slate-750 font-sans">
                  {selectedFile.badge}
                </span>
              </div>
              
              <button
                onClick={handleSave}
                disabled={isSaving}
                className="flex items-center gap-1.5 px-3 py-1 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white text-xs font-semibold rounded-md transition-colors cursor-pointer"
              >
                <Save className="h-3.5 w-3.5" id="save-btn-icon" />
                {isSaving ? 'Saving...' : 'Save File'}
              </button>
            </div>

            {/* Save Status alerts */}
            {saveStatus && (
              <div className={`flex items-center gap-2 px-4 py-2.5 text-xs font-medium border-b ${
                saveStatus.type === 'success'
                  ? 'bg-emerald-950/25 border-emerald-900 text-emerald-400'
                  : 'bg-rose-950/25 border-rose-900 text-rose-400'
              }`}>
                {saveStatus.type === 'success' ? (
                  <CheckCircle className="h-4 w-4" />
                ) : (
                  <AlertCircle className="h-4 w-4" />
                )}
                {saveStatus.text}
              </div>
            )}

            {/* RAW Source Code Editor body */}
            <div className="flex-1 flex flex-col">
              <textarea
                value={editedContent}
                onChange={(e) => setEditedContent(e.target.value)}
                spellCheck={false}
                autoFocus={false}
                className="w-full flex-1 min-h-[440px] max-h-[500px] p-4 bg-slate-950 text-slate-300 font-mono text-xs focus:outline-hidden resize-none leading-relaxed overflow-auto leading-6 tab-size-4"
                style={{ tabSize: 4 }}
              />
            </div>

            {/* Custom footer indicator banner */}
            <div className="px-4 py-2 bg-slate-950 border-t border-slate-900 flex justify-between items-center text-[10px] text-slate-500 font-mono">
              <span>Lines: {editedContent.split('\n').length}</span>
              <span>Encoding: UTF-8</span>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col justify-center items-center text-slate-500 gap-2 h-full">
            <FileCode className="h-10 w-10 text-slate-750" />
            <span className="text-xs">No active file selected for inspection.</span>
          </div>
        )}
      </div>
    </div>
  );
}
