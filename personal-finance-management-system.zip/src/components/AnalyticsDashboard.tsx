import React, { useState } from 'react';
import {
  ResponsiveContainer, PieChart, Pie, Cell, Tooltip,
  BarChart, Bar, XAxis, YAxis, Legend, AreaChart, Area, CartesianGrid
} from 'recharts';
import { Wallet, TrendingUp, TrendingDown, Landmark, Copy, Check, Download, TableProperties, LineChart } from 'lucide-react';
import { IncomeRecord, ExpenseRecord } from '../types';

interface AnalyticsDashboardProps {
  incomes: IncomeRecord[];
  expenses: ExpenseRecord[];
}

export default function AnalyticsDashboard({ incomes, expenses }: AnalyticsDashboardProps) {
  const [copiedCsv, setCopiedCsv] = useState<boolean>(false);

  // Financial aggregates recalculations
  const totalIncome = incomes.reduce((sum, i) => sum + i.amount, 0);
  const totalExpense = expenses.reduce((sum, e) => sum + e.amount, 0);
  const balance = totalIncome - totalExpense;
  const savingsPct = totalIncome > 0 ? ((totalIncome - totalExpense) / totalIncome) * 100 : 0;

  // Chart Data 1: Inflow vs Outflow Splits
  const splitChartData = [
    { name: 'Income', value: totalIncome, color: '#10b981' }, // emerald-500
    { name: 'Expenses', value: totalExpense, color: '#f43f5e' }  // rose-500
  ].filter(item => item.value > 0);

  // Chart Data 2: Spending Category Bars
  const categoriesList = ['Food', 'Shopping', 'Travel', 'Education', 'Entertainment', 'Others'];
  const categoryChartData = categoriesList.map(cat => {
    const total = expenses.filter(e => e.category === cat).reduce((sum, e) => sum + e.amount, 0);
    return { name: cat, Amount: total };
  });

  // Chart Data 3: Monthly Trends Area Mapping
  const getMonthlyTrendData = () => {
    const monthlySummary: { [month: string]: { income: number; expense: number } } = {};
    
    incomes.forEach(i => {
      const monthStr = i.date.substring(0, 7); // "YYYY-MM"
      if (!monthlySummary[monthStr]) monthlySummary[monthStr] = { income: 0, expense: 0 };
      monthlySummary[monthStr].income += i.amount;
    });

    expenses.forEach(e => {
      const monthStr = e.date.substring(0, 7); // "YYYY-MM"
      if (!monthlySummary[monthStr]) monthlySummary[monthStr] = { income: 0, expense: 0 };
      monthlySummary[monthStr].expense += e.amount;
    });

    return Object.keys(monthlySummary).sort().map(m => ({
      Month: m,
      Income: monthlySummary[m].income,
      Expense: monthlySummary[m].expense,
      Balance: monthlySummary[m].income - monthlySummary[m].expense
    }));
  };

  const trendChartData = getMonthlyTrendData();

  // CSV Generator for Tableau
  const generateTableauCsvString = (): string => {
    const rows = [["Date", "Category", "Type", "Income", "Expense", "Running_Balance"]];
    const combined: any[] = [];

    incomes.forEach(i => {
      combined.push({ date: i.date, category: `Income: ${i.source}`, type: "Income", income: i.amount, expense: 0 });
    });

    expenses.forEach(e => {
      combined.push({ date: e.date, category: e.category, type: "Expense", income: 0, expense: e.amount });
    });

    combined.sort((a, b) => (a.date > b.date ? 1 : -1));

    let runBal = 0;
    combined.forEach(tx => {
      runBal += tx.income;
      runBal -= tx.expense;
      rows.push([
        tx.date,
        tx.category,
        tx.type,
        tx.income.toFixed(2),
        tx.expense.toFixed(2),
        runBal.toFixed(2)
      ]);
    });

    return rows.map(r => r.join(',')).join('\n');
  };

  const handleCopyCsv = () => {
    navigator.clipboard.writeText(generateTableauCsvString());
    setCopiedCsv(true);
    setTimeout(() => setCopiedCsv(false), 2000);
  };

  const handleDownloadCsvFile = () => {
    const csvContent = "data:text/csv;charset=utf-8," + encodeURIComponent(generateTableauCsvString());
    const link = document.createElement("a");
    link.setAttribute("href", csvContent);
    link.setAttribute("download", "transactions.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Dynamic Key Performance Indicator (KPI) Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {/* KPI 1 */}
        <div className="p-4 bg-white rounded-xl border border-slate-100 shadow-xs flex items-center gap-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-lg shrink-0">
            <TrendingUp className="h-6 w-6" />
          </div>
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Total Income</span>
            <span className="text-xl font-bold font-mono text-slate-800">${totalIncome.toFixed(2)}</span>
          </div>
        </div>

        {/* KPI 2 */}
        <div className="p-4 bg-white rounded-xl border border-slate-100 shadow-xs flex items-center gap-4">
          <div className="p-3 bg-rose-50 text-rose-600 rounded-lg shrink-0">
            <TrendingDown className="h-6 w-6" />
          </div>
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Total Expenses</span>
            <span className="text-xl font-bold font-mono text-slate-800">${totalExpense.toFixed(2)}</span>
          </div>
        </div>

        {/* KPI 3 */}
        <div className="p-4 bg-white rounded-xl border border-slate-100 shadow-xs flex items-center gap-4">
          <div className={`p-3 rounded-lg shrink-0 ${balance >= 0 ? 'bg-indigo-50 text-indigo-600' : 'bg-red-50 text-red-650'}`}>
            <Wallet className="h-6 w-6" />
          </div>
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Ledger Balance</span>
            <span className={`text-xl font-bold font-mono ${balance >= 0 ? 'text-indigo-600' : 'text-red-600'}`}>
              ${balance.toFixed(2)}
            </span>
          </div>
        </div>

        {/* KPI 4 */}
        <div className="p-4 bg-white rounded-xl border border-slate-100 shadow-xs flex items-center gap-4">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-lg shrink-0">
            <Landmark className="h-6 w-6" />
          </div>
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Savings Percentage</span>
            <span className="text-xl font-bold font-mono text-slate-800">{Math.max(0, savingsPct).toFixed(1)}%</span>
          </div>
        </div>
      </div>

      {/* Recharts Visualizations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Spending category bar chart */}
        <div className="lg:col-span-8 p-5 bg-white rounded-xl border border-slate-100 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-800 mb-1" id="cat-breakdown-title">Category Consumption Breakdown</h3>
            <p className="text-[11px] text-slate-400 mb-4 leading-normal">
              Comparing dynamic expenditures across all valid categories (Food, Shopping, Travel, etc.) based on SQLite rows.
            </p>
          </div>
          
          <div className="h-[250px] w-full mt-2">
            {expenses.length === 0 ? (
              <div className="h-full flex items-center justify-center text-xs text-slate-400 border border-dashed border-slate-200 rounded">
                No active expenditures entered yet.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '6px' }}
                    labelStyle={{ color: '#fff', fontSize: '11px', fontWeight: 'bold' }}
                    itemStyle={{ color: '#818cf8', fontSize: '10px' }}
                  />
                  <Bar dataKey="Amount" fill="#6366f1" radius={[4, 4, 0, 0]} barSize={34} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Wallet Split Ratio Pie Chart */}
        <div className="lg:col-span-4 p-5 bg-white rounded-xl border border-slate-100 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-800 mb-1" id="ratio-split-title">Ledger Splits Ratio</h3>
            <p className="text-[11px] text-slate-400 mb-4 leading-normal">
              Showing total credit versus debit balances stored logically.
            </p>
          </div>

          <div className="h-[200px] w-full flex items-center justify-center relative">
            {splitChartData.length === 0 ? (
              <div className="h-full w-full flex items-center justify-center text-xs text-slate-400 border border-dashed border-slate-200 rounded">
                No transactions recorded.
              </div>
            ) : (
              <>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={splitChartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={75}
                      paddingAngle={3}
                      dataKey="value"
                    >
                      {splitChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '6px' }}
                      itemStyle={{ color: '#fff', fontSize: '10px' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                {/* Center text sum details */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <span className="text-[9px] text-slate-400 uppercase tracking-widest font-bold">Sum Vault</span>
                  <span className="text-sm font-bold text-slate-700 font-mono">${(totalIncome + totalExpense).toFixed(0)}</span>
                </div>
              </>
            )}
          </div>

          <div className="flex justify-center gap-6 mt-2 pb-1 border-t border-slate-50 pt-3">
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-500">
              <span className="h-2 w-2 rounded-full bg-emerald-500"></span>
              Incomes: ${totalIncome.toFixed(0)}
            </div>
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-500">
              <span className="h-2 w-2 rounded-full bg-rose-500"></span>
              Expenses: ${totalExpense.toFixed(0)}
            </div>
          </div>
        </div>
      </div>

      {/* Trend Cashflow lines charts */}
      {trendChartData.length > 0 && (
        <div className="p-5 bg-white rounded-xl border border-slate-100 shadow-xs">
          <div className="flex items-center gap-2 mb-1">
            <LineChart className="h-4.5 w-4.5 text-indigo-500" />
            <h3 className="text-sm font-semibold text-slate-800">Monthly Cash Inflow vs Outflow Dynamics</h3>
          </div>
          <p className="text-[11px] text-slate-400 mb-5 leading-normal">
            Visualizing the dynamic shifts in ledger trends across chronological sequences, calculated programmatically from SQLite.
          </p>

          <div className="h-[220px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorInc" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorExp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="Month" stroke="#94a3b8" fontSize={10} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '6px' }}
                  labelStyle={{ color: '#fff', fontSize: '11px', fontWeight: 'bold' }}
                />
                <Legend iconSize={8} wrapperStyle={{ fontSize: '10px', paddingTop: '10px' }} />
                <Area type="monotone" dataKey="Income" stroke="#10b981" strokeWidth={1.8} fillOpacity={1} fill="url(#colorInc)" />
                <Area type="monotone" dataKey="Expense" stroke="#f43f5e" strokeWidth={1.8} fillOpacity={1} fill="url(#colorExp)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Tableau Ingestion Workspace Portal */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-3.5 border-b border-slate-800 gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <TableProperties className="h-5 w-5 text-indigo-400" id="tableau-grid-icon" />
              <h3 className="text-sm font-semibold text-slate-200" id="tableau-dataset-title text-indigo-100">Tableau DB Ingestion Dataset</h3>
            </div>
            <p className="text-[10px] text-slate-500 leading-normal">
              Compiled chronological CSV payload representing your financial logs database. This formatted CSV table is ready to feed straight into Tableau Sheets.
            </p>
          </div>
          
          <div className="flex gap-2 shrink-0">
            <button
              onClick={handleCopyCsv}
              className="flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 hover:text-white border border-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
            >
              {copiedCsv ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  Copy CSV
                </>
              )}
            </button>
            <button
              onClick={handleDownloadCsvFile}
              className="flex items-center gap-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              Download CSV
            </button>
          </div>
        </div>

        {/* Raw CSV Data Render Block */}
        <div className="bg-slate-950 rounded-lg p-4 font-mono text-[10px] text-indigo-300 max-h-[160px] overflow-y-auto leading-relaxed border border-slate-850/60 leading-5">
          {generateTableauCsvString()}
        </div>
      </div>
    </div>
  );
}
