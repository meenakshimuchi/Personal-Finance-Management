import React, { useState } from 'react';
import { BookOpen, Copy, Check, Award, Compass, Key } from 'lucide-react';
import { InterviewQuestion } from '../types';

export default function InterviewPreparer() {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [revealedIndex, setRevealedIndex] = useState<number | null>(null);

  const resumeBullets = [
    "Designed and engineered an OOP-based Personal Finance Management System utilizing Python and SQLite3, creating a securely hashed login framework (SHA-256) handling multi-user credentials.",
    "Implemented core linear data structures from scratch, incorporating a custom Stack (LIFO) to power an instant transactional Undo Engine and a custom Queue (FIFO) to maintain a sliding session notification tracker.",
    "Constructed a custom Singly Linked List with an embedded Bubble Sort sorting algorithm to aggregate, index, and traverse unified financial entries chronologically by date.",
    "Integrated Pandas DataFrames to automate user metrics processing, calculating monthly consumption trends, average outflows, and multi-category expense aggregates.",
    "Programmed a beautiful dynamic report exporter using OpenPyXL to format multi-sheet MS Excel workbooks with custom styles, borders, formulas, and visual highlights.",
    "Serialized relational database records into structured, sorted CSV datasets tailored for seamless Tableau/PowerBI dashboard ingestion and line/area balance visualization."
  ];

  const interviewQuestions: InterviewQuestion[] = [
    {
      category: "Data Structures (DSA)",
      question: "Why use a custom Singly Linked List instead of Python's default lists?",
      answer: "A standard Python list is implemented as a contiguous dynamic array, which has O(N) complexity for insertions and deletions at arbitrary locations due to cell shifting. A custom Singly Linked List permits O(1) node updates/additions once pointers are isolated. It demonstrates fundamental pointer manipulation, node traversal, and independent memory management suitable for memory-efficient ledger records."
    },
    {
      category: "Data Structures (DSA)",
      question: "Explain how your Stack class implements the Undo Engine.",
      answer: "The ActionStack follows Last-In-First-Out (LIFO). Whenever a CRUD operation occurs (Addition, Deletion, Update), a transaction node containing the table, row ID, and past data is pushed onto the stack. Selecting 'Undo' pops this action. The database manager processes this action to reverse changes (e.g. DELETE if added, INSERT if removed, UPDATE if changed) in stable O(1) push/pop complexity."
    },
    {
      category: "Databases (SQL)",
      question: "What are check constraints and how are they used in SQLite?",
      answer: "Check constraints enforce domain integrity rules directly at the DB layer. In our schema: 'amount REAL CHECK(amount > 0)' guarantees no negative or zero transactions are saved. 'category TEXT CHECK(category IN (...))' prevents incorrect category insertion, protecting data cleanliness before it reaches Pandas."
    },
    {
      category: "Programming (OOP)",
      question: "Why use Object-Oriented Programming (OOP) in a student finance project?",
      answer: "OOP introduces encapsulations and modularity. By wrapping databases into 'DatabaseManager', authentication into 'AuthManager', and transactions into 'IncomeManager'/'ExpenseManager', we prevent monolithic code smells. Logic is separated from presentation, matching SOLID developer practices."
    },
    {
      category: "Data Analytics (Pandas/Excel)",
      question: "How does Pandas assist in processing and aggregates calculation?",
      answer: "Pandas loads SQLite columns directly into multi-dimensional NumPy-backed structures called DataFrames. It uses vectorization to perform O(N) aggregates like mathematical groupby operations ('df.groupby(\"Category\")[\"Amount\"].sum()'), which are heavily optimized in C, surpassing raw Python loop performance."
    },
    {
      category: "Data Analytics (Pandas/Excel)",
      question: "Explain how OpenPyXL is configured to format the spreadsheet.",
      answer: "OpenPyXL grants cell-level control. We programmatically map workbook worksheets, define style fonts (Segoe UI), color cell cells (Navy headers), adjust gridline view states, configure column width spans, and embed standard formula equations ('=SUM(C5:C20)') directly, mimicking corporate financial reporting."
    }
  ];

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="space-y-6" id="interview-prep">
      {/* Resume Booster Section */}
      <div className="bg-white rounded-xl shadow-xs border border-slate-100 p-6">
        <div className="flex items-center gap-2 mb-4">
          <Award className="h-6 w-6 text-indigo-600" id="bullet-award-icon" />
          <h2 className="text-lg font-semibold text-slate-800" id="bullet-builder-title">Resume Builder Corner</h2>
        </div>
        <p className="text-sm text-slate-500 mb-6 leading-relaxed">
          Copy these high-impact, professional descriptors into your resume under the **Projects** or **Key Academic Works** section. It highlights your data structures expertise, database engineering skills, and visual science familiarity:
        </p>

        <div className="space-y-4">
          {resumeBullets.map((bullet, idx) => (
            <div key={idx} className="group relative flex items-start justify-between gap-4 p-3 bg-slate-50 rounded-lg border border-slate-100 hover:border-indigo-100 transition-colors">
              <p className="text-sm text-slate-600 leading-relaxed pr-8" id={`bullet-${idx}`}>{bullet}</p>
              <button
                onClick={() => copyToClipboard(bullet, idx)}
                id={`copy-bullet-${idx}`}
                className="absolute right-3 top-3 p-1.5 rounded-md hover:bg-slate-200 text-slate-400 hover:text-slate-600 transition-all cursor-pointer"
                title="Copy to clipboard"
              >
                {copiedIndex === idx ? (
                  <Check className="h-4 w-4 text-emerald-600" id={`check-icon-${idx}`} />
                ) : (
                  <Copy className="h-4 w-4" id={`copy-icon-${idx}`} />
                )}
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Viva Q&A Guide */}
      <div className="bg-white rounded-xl shadow-xs border border-slate-100 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-amber-500" id="viva-book-icon" />
            <h2 className="text-lg font-semibold text-slate-800" id="viva-questions-title">Viva-Voce Oral Exam Prep</h2>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 bg-amber-50 text-amber-700 rounded-full border border-amber-100">
            6 Core Concepts
          </span>
        </div>
        <p className="text-sm text-slate-500 mb-6 leading-relaxed">
          Prepare for external examiners and vivas. Click each question card to flip and verify its architectural explanation and technical justification:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {interviewQuestions.map((item, idx) => (
            <div
              key={idx}
              onClick={() => setRevealedIndex(revealedIndex === idx ? null : idx)}
              className={`p-4 rounded-xl border transition-all cursor-pointer select-none text-left flex flex-col justify-between min-h-[170px] ${
                revealedIndex === idx
                  ? "bg-slate-900 border-slate-800 shadow-sm"
                  : "bg-white border-slate-200 hover:border-indigo-200 hover:shadow-xs"
              }`}
            >
              <div>
                <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-md mb-2 tracking-wider uppercase ${
                  revealedIndex === idx ? "bg-slate-800 text-indigo-300" : "bg-cyan-50 text-cyan-700"
                }`}>
                  {item.category}
                </span>
                <h3 className={`text-sm font-semibold leading-snug ${
                  revealedIndex === idx ? "text-slate-100" : "text-slate-800"
                }`}>
                  {item.question}
                </h3>
              </div>

              <div className="mt-4 pt-2 border-t border-dashed border-slate-100/10">
                {revealedIndex === idx ? (
                  <p className="text-xs text-slate-300 leading-relaxed bg-slate-800/40 p-2 rounded-lg border border-slate-800">
                    {item.answer}
                  </p>
                ) : (
                  <span className="text-xs text-indigo-600 font-medium flex items-center gap-1">
                    <Key className="h-3 w-3" /> Click to reveal viva answer
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Future enhancements and tips info */}
      <div className="bg-indigo-50/50 rounded-xl border border-indigo-100 p-6 flex gap-4">
        <Compass className="h-8 w-8 text-indigo-600 shrink-0 mt-1" id="compass-icon" />
        <div>
          <h4 className="text-sm font-semibold text-indigo-900 mb-1" id="evaluation-tip-title">Academic Board Presentation Tip</h4>
          <p className="text-xs text-indigo-700 leading-relaxed">
            When displaying this code to college professors, stress that your <strong>Stack (Undo Engine)</strong> has a strict <strong>O(1) complexity</strong>. Also mention that since it operates directly via local indices, your SQLite DB maintains optimal normalization and respects third-normal form rules (3NF).
          </p>
        </div>
      </div>
    </div>
  );
}
