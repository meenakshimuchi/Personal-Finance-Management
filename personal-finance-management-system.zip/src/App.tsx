import React, { useState } from 'react';
import { Sparkles, Terminal, Code2, Presentation, FolderCode, GraduationCap, Github, BookOpen } from 'lucide-react';
import FileExplorer from './components/FileExplorer';
import TerminalSimulator from './components/TerminalSimulator';
import AnalyticsDashboard from './components/AnalyticsDashboard';
import InterviewPreparer from './components/InterviewPreparer';
import { IncomeRecord, ExpenseRecord } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<'terminal' | 'explorer' | 'visuals' | 'prep'>('terminal');

  // Prepopulate with elegant realistic sample student transactions
  const [incomes, setIncomes] = useState<IncomeRecord[]>([
    { id: 1, amount: 2500, source: 'Scholarship Stipend', date: '2026-05-01' },
    { id: 2, amount: 800, source: 'Freelance Design', date: '2026-05-15' },
    { id: 3, amount: 1500, source: 'Academic Grant Allowance', date: '2026-06-01' },
    { id: 4, amount: 350, source: 'Technical Writing', date: '2026-06-10' }
  ]);

  const [expenses, setExpenses] = useState<ExpenseRecord[]>([
    { id: 1, amount: 450, category: 'Education', date: '2026-05-02' },
    { id: 2, amount: 120, category: 'Food', date: '2026-05-10' },
    { id: 3, amount: 500, category: 'Shopping', date: '2026-05-18' },
    { id: 4, amount: 80, category: 'Travel', date: '2026-05-24' },
    { id: 5, amount: 150, category: 'Entertainment', date: '2026-06-03' },
    { id: 6, amount: 220, category: 'Others', date: '2026-06-11' }
  ]);

  const handleDataChange = (newIncomes: IncomeRecord[], newExpenses: ExpenseRecord[]) => {
    setIncomes(newIncomes);
    setExpenses(newExpenses);
  };

  return (
    <div className="min-h-screen bg-slate-50/50 flex flex-col justify-between" id="root-viewport">
      {/* Premium Header Layout */}
      <header className="bg-slate-900 border-b border-slate-800 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-indigo-6500 bg-gradient-to-tr from-indigo-600 to-indigo-500 rounded-xl shadow-lg ring-1 ring-white/10 shrink-0">
                <Sparkles className="h-6 w-6 text-white" id="header-sparkle" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl font-bold font-sans tracking-tight text-white" id="applet-heading">
                    Personal Finance Management System (PFMS)
                  </h1>
                  <span className="hidden sm:inline-block text-[10px] font-bold px-2 py-0.5 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded">
                    B.Tech CSBS Portfolio
                  </span>
                </div>
                <p className="text-xs text-slate-400 font-sans mt-0.5">
                  Computer Science & Business Systems Laboratory Project Environment
                </p>
              </div>
            </div>

            {/* Academic Credit Details */}
            <div className="flex items-center gap-3 bg-slate-800/40 px-3.5 py-1.5 rounded-lg border border-slate-750 shrink-0">
              <GraduationCap className="h-5 w-5 text-indigo-400" />
              <div className="text-right">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Academic Evaluation</span>
                <span className="text-xs font-semibold text-slate-200">First-Year Coursework Project</span>
              </div>
            </div>
          </div>

          {/* Navigation tabs */}
          <div className="flex gap-2.5 mt-6 border-t border-slate-800/60 pt-4 overflow-x-auto">
            <button
              onClick={() => setActiveTab('terminal')}
              id="tab-terminal"
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'terminal'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <Terminal className="h-4.5 w-4.5" />
              Interactive CLI Simulator
            </button>
            <button
              onClick={() => setActiveTab('explorer')}
              id="tab-explorer"
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'explorer'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <FolderCode className="h-4.5 w-4.5" />
              Python File Explorer
            </button>
            <button
              onClick={() => setActiveTab('visuals')}
              id="tab-visuals"
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'visuals'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <Presentation className="h-4.5 w-4.5" />
              tableau & Pandas Dashboard
            </button>
            <button
              onClick={() => setActiveTab('prep')}
              id="tab-prep"
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'prep'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <GraduationCap className="h-4.5 w-4.5" />
              viva Q&A & Resume Booster
            </button>
          </div>
        </div>
      </header>

      {/* Main Container Content */}
      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1" id="main-content-panel">
        {activeTab === 'terminal' && (
          <div className="space-y-4">
            <div className="p-4 bg-amber-50 border border-amber-200 text-amber-800 rounded-xl text-xs leading-relaxed max-w-3xl flex items-start gap-2.5">
              <GraduationCap className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
              <span>
                <strong>Academic sandbox:</strong> This terminal runs a simulation of your <strong>SQLite and data structure algorithms</strong> logic inside standard React states. Use shortcuts below the CLI or type indexes directly to register/login (default credential: <strong>admin</strong> / <strong>admin</strong>) and trace Stack operations or Linked Lists!
              </span>
            </div>
            <TerminalSimulator
              onDataChange={handleDataChange}
              incomes={incomes}
              expenses={expenses}
            />
          </div>
        )}

        {activeTab === 'explorer' && (
          <div className="space-y-4">
            <div className="p-4 bg-indigo-50 border border-indigo-100 text-indigo-900 rounded-xl text-xs leading-relaxed max-w-3xl flex items-start gap-2.5">
              <GraduationCap className="h-5 w-5 text-indigo-600 shrink-0 mt-0.5" />
              <span>
                <strong>Workspace Sync Server:</strong> This panel reads and displays files straight from the backend root folder <code>Personal_Finance_Management_System/</code>. Feel free to edit files in this tree and save changes. Your modifications will persist directly in the folder workspace. Use the full ZIP option to download!
              </span>
            </div>
            <FileExplorer />
          </div>
        )}

        {activeTab === 'visuals' && (
          <AnalyticsDashboard
            incomes={incomes}
            expenses={expenses}
          />
        )}

        {activeTab === 'prep' && (
          <InterviewPreparer />
        )}
      </main>

      {/* Applet Footer information block */}
      <footer className="bg-slate-900 text-slate-400 py-6 border-t border-slate-800 text-xs text-center" id="footer-metadata">
        <div className="max-w-7xl mx-auto px-4 space-y-2">
          <p>
            Developed with professional academic criteria for <strong>Computer Science & Business Systems (CSBS)</strong> engineering students.
          </p>
          <p className="text-[10px] text-slate-500">
            Powered by python, sqlite3, Pandas, OpenPyXL, and interactive React + Recharts workspaces.
          </p>
        </div>
      </footer>
    </div>
  );
}
